package com.example.arrowpuzzle;

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class MainActivity extends BridgeActivity {
    
    private String gameId = "6094029";
    private boolean testMode = false;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    @Override
    public void onStart() {
        super.onStart();
        
        WebView webView = this.bridge.getWebView();
        if (webView != null) {
            webView.addJavascriptInterface(new UnityAdsJSInterface(), "AndroidUnityAds");
        }
    }
    
    private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
        @Override
        public void onUnityAdsAdLoaded(String placementId) {}
        @Override
        public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {}
    };
    
    private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
        @Override
        public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
            evaluateJavascript("window.onUnityAdFinished && window.onUnityAdFinished('" + placementId + "', 'FAILED');");
            UnityAds.load(placementId, loadListener);
        }

        @Override
        public void onUnityAdsShowStart(String placementId) {}

        @Override
        public void onUnityAdsShowClick(String placementId) {}

        @Override
        public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
            String result = "COMPLETED";
            if (state == UnityAds.UnityAdsShowCompletionState.SKIPPED) {
                result = "SKIPPED";
            }
            evaluateJavascript("window.onUnityAdFinished && window.onUnityAdFinished('" + placementId + "', '" + result + "');");
            UnityAds.load(placementId, loadListener);
        }
    };
    
    private void evaluateJavascript(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                WebView webView = bridge.getWebView();
                if (webView != null) {
                    webView.evaluateJavascript(js, null);
                }
            }
        });
    }
    
    private class UnityAdsJSInterface {
        @JavascriptInterface
        public void initialize(String id, boolean test) {
            gameId = id;
            testMode = test;
            
            UnityAds.initialize(MainActivity.this, gameId, testMode, new IUnityAdsInitializationListener() {
                @Override
                public void onInitializationComplete() {
                    UnityAds.load("Interstitial_Android", loadListener);
                    UnityAds.load("Rewarded_Android", loadListener);
                }

                @Override
                public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {}
            });
        }
        
        @JavascriptInterface
        public void showInterstitial(final String placementId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    UnityAds.show(MainActivity.this, placementId, new UnityAdsShowOptions(), showListener);
                }
            });
        }
        
        @JavascriptInterface
        public void showRewarded(final String placementId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    UnityAds.show(MainActivity.this, placementId, new UnityAdsShowOptions(), showListener);
                }
            });
        }
        
        @JavascriptInterface
        public boolean isReady(String placementId) {
            return true;
        }
    }
}
