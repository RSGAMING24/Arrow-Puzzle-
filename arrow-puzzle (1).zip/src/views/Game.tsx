import React, { useState, useEffect, useRef } from 'react';
import { ViewState } from '../App';
import { Arrow, LevelData, PlayerProgress } from '../types';
import { isPathClear, getHint, getBlockingArrowIds } from '../lib/gameLogic';
import { cn, playVibration, playSound } from '../lib/utils';
import { ArrowSvg } from '../components/ArrowSvg';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Lightbulb, Pause, RotateCcw, Heart, Play, Star, MonitorPlay } from 'lucide-react';
import { UnityAds } from '../lib/unityAdsBridge';

interface GameProps {
  onNavigate: (v: ViewState, level?: number) => void;
  levelNumber: number;
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
  levels: LevelData[];
}

export function Game({ onNavigate, levelNumber, progress, setProgress, levels }: GameProps) {
  const levelData = levels.find(l => l.number === levelNumber) || levels[0];
  const [arrows, setArrows] = useState<Arrow[]>(levelData.arrows);
  const [hearts, setHearts] = useState(3);
  const [hints, setHints] = useState(1);
  const [moves, setMoves] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [gameState, setGameState] = useState<'playing' | 'completed' | 'failed' | 'paused'>('playing');
  const [exitingArrows, setExitingArrows] = useState<Arrow[]>([]);
  const [hintArrowId, setHintArrowId] = useState<string | null>(null);
  const [longPressId, setLongPressId] = useState<string | null>(null);
  const [errorArrowIds, setErrorArrowIds] = useState<string[]>([]);
  const [waitingArrowIds, setWaitingArrowIds] = useState<string[]>([]);
  const [earnedCoins, setEarnedCoins] = useState<number | null>(null);
  const [adLoading, setAdLoading] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  // Reset state when level changes
  useEffect(() => {
    setArrows(levelData.arrows);
    setHearts(3);
    setHints(1);
    setMoves(0);
    setMistakes(0);
    setGameState('playing');
    setExitingArrows([]);
    setHintArrowId(null);
    setLongPressId(null);
    setErrorArrowIds([]);
    setWaitingArrowIds([]);
    setEarnedCoins(null);
  }, [levelData]);

  // Check completion
  useEffect(() => {
    if (arrows.length === 0 && gameState === 'playing' && exitingArrows.length === 0) {
      setGameState('completed');
      playSound('success', progress.settings?.sound ?? true);
      playVibration(100);
      
      // Calculate stars
      let stars = 3;
      if (mistakes > 0) stars = 2;
      if (mistakes > Math.max(1, levelData.hearts - 1)) stars = 1;

      // Update progress
      const newProgress = { ...progress };
      const currentStats = newProgress.completedLevels[levelNumber];
      
      if (!currentStats || currentStats.stars < stars) {
        newProgress.completedLevels[levelNumber] = { stars, moves, mistakes };
      }

      // Add coins if first time completing this level
      if (!currentStats && earnedCoins === null) {
        const reward = levelData.coinReward || 5;
        newProgress.coins = (newProgress.coins || 0) + reward;
        setEarnedCoins(reward);
      } else if (earnedCoins === null) {
        setEarnedCoins(0);
      }
      
      // Unlock next level
      const nextLevel = levelNumber + 1;
      const maxLevel = levels.length > 0 ? Math.max(...levels.filter(l => l.status === 'Live').map(l => l.number)) : 100;
      
      if (nextLevel <= maxLevel && !newProgress.unlockedLevels.includes(nextLevel) && levels.some(l => l.number === nextLevel && l.status === 'Live')) {
        newProgress.unlockedLevels.push(nextLevel);
      }
      
      if (newProgress.currentLevel === levelNumber && nextLevel <= maxLevel) {
        newProgress.currentLevel = nextLevel;
      }
      
      setProgress(newProgress);
    }
  }, [arrows, exitingArrows, gameState, mistakes, levelNumber, progress, setProgress, levels, levelData.hearts]);

  const handlePointerDown = (arrow: Arrow) => {
    if (gameState !== 'playing') return;
    
    // Clear any existing timer
    if (pressTimer.current) clearTimeout(pressTimer.current);
    
    pressTimer.current = setTimeout(() => {
      setLongPressId(arrow.id);
      playVibration(20);
    }, 400); // 400ms long press threshold
  };

  const handlePointerUp = (arrow: Arrow) => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
    
    if (longPressId === arrow.id) {
      // It was a long press, don't trigger normal tap, just clear the guidance
      setLongPressId(null);
    } else {
      // It was a short tap, clear any lingering guidance and execute logic
      setLongPressId(null);
      handleArrowTap(arrow);
    }
  };

  const handlePointerLeave = () => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
    setLongPressId(null);
  };

  const handleArrowTap = (arrow: Arrow) => {
    if (gameState !== 'playing') return;
    if (waitingArrowIds.includes(arrow.id)) return;
    
    setHintArrowId(null);
    setMoves(m => m + 1);

    if (isPathClear(arrow, arrows, levelData.gridSize)) {
      playSound('tap', progress.settings?.sound ?? true);
      playVibration(30);
      
      // Remove from active, add to exiting
      setArrows(prev => prev.filter(a => a.id !== arrow.id));
      setExitingArrows(prev => [...prev, arrow]);
      
      // Cleanup exiting arrow after animation
      setTimeout(() => {
        setExitingArrows(prev => prev.filter(a => a.id !== arrow.id));
      }, 400); // match animation duration
    } else {
      playSound('error', progress.settings?.sound ?? true);
      playVibration([50, 50, 50]);
      setMistakes(m => m + 1);
      
      // Show error animation ONLY on tapped arrow
      setErrorArrowIds([arrow.id]);
      setTimeout(() => setErrorArrowIds([]), 400);
      
      // Keep it red and wait for a path to clear
      setWaitingArrowIds(prev => [...prev, arrow.id]);
      
      const newHearts = hearts - 1;
      setHearts(newHearts);
      
      if (newHearts <= 0) {
        setGameState('failed');
      }
    }
  };

  const totalHints = hints + (progress.inventory?.globalHints || 0);

  const useHint = async () => {
    if (gameState !== 'playing' || hintArrowId || adLoading) return;
    
    if (totalHints > 0) {
      const hintArrow = getHint(arrows, levelData.gridSize);
      if (hintArrow) {
        if (hints > 0) {
          setHints(h => h - 1);
        } else if ((progress.inventory?.globalHints || 0) > 0) {
          setProgress(prev => ({
            ...prev,
            inventory: {
              ...prev.inventory!,
              globalHints: Math.max(0, prev.inventory!.globalHints - 1)
            }
          }));
        }
        setHintArrowId(hintArrow.id);
        playVibration(20);
      }
    } else {
      setAdLoading(true);
      const success = await UnityAds.showRewarded();
      setAdLoading(false);
      
      if (success) {
        const hintArrow = getHint(arrows, levelData.gridSize);
        if (hintArrow) {
          setHintArrowId(hintArrow.id);
          playVibration(20);
        }
      }
    }
  };

  // Auto-exit waiting arrows when path clears
  useEffect(() => {
    if (waitingArrowIds.length === 0 || gameState !== 'playing') return;

    const arrowsToExit = waitingArrowIds.filter(id => {
      const arrow = arrows.find(a => a.id === id);
      return arrow && isPathClear(arrow, arrows, levelData.gridSize);
    });

    if (arrowsToExit.length > 0) {
      playSound('tap', progress.settings?.sound ?? true);
      playVibration(30);

      setWaitingArrowIds(prev => prev.filter(id => !arrowsToExit.includes(id)));
      
      const exitingObjects = arrowsToExit.map(id => arrows.find(a => a.id === id)!).filter(Boolean);
      
      setArrows(prev => prev.filter(a => !arrowsToExit.includes(a.id)));
      setExitingArrows(prev => [...prev, ...exitingObjects]);

      setTimeout(() => {
        setExitingArrows(prev => prev.filter(a => !arrowsToExit.includes(a.id)));
      }, 400);
    }
  }, [arrows, waitingArrowIds, gameState, levelData.gridSize, progress.settings?.sound]);

  const restartLevel = () => {
    setArrows(levelData.arrows);
    setHearts(3);
    setHints(1);
    setMoves(0);
    setMistakes(0);
    setGameState('playing');
    setExitingArrows([]);
    setHintArrowId(null);
    setLongPressId(null);
    setErrorArrowIds([]);
    setWaitingArrowIds([]);
  };

  const handleNextLevel = async () => {
    setAdLoading(true);
    await UnityAds.showInterstitial();
    setAdLoading(false);
    
    const next = levels.find(l => l.number === levelNumber + 1 && l.status === 'Live');
    if (next) onNavigate('GAME', next.number);
    else onNavigate('LEVEL_SELECT');
  };

  const [boardWidth, setBoardWidth] = useState(300);
  useEffect(() => {
    const handleResize = () => {
      const maxW = 448; // max-w-md is 448px
      const padding = 32; // p-4 on left and right = 32px
      const available = Math.min(window.innerWidth, maxW) - padding;
      setBoardWidth(available);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Rendering
  const cellSize = boardWidth / levelData.gridSize;
  const boardSize = boardWidth;

  const getArrowRotation = (dir: Arrow['direction']) => {
    switch (dir) {
      case 'UP': return -90;
      case 'RIGHT': return 0;
      case 'DOWN': return 90;
      case 'LEFT': return 180;
    }
  };

  const getExitAnimation = (dir: Arrow['direction']) => {
    const dist = boardSize;
    const animType = progress.equipped?.animation;
    
    if (animType === 'SPIN') {
       switch (dir) {
          case 'UP': return { y: -dist, opacity: 0, rotate: 720, scale: 0.5 };
          case 'DOWN': return { y: dist, opacity: 0, rotate: 720, scale: 0.5 };
          case 'LEFT': return { x: -dist, opacity: 0, rotate: -720, scale: 0.5 };
          case 'RIGHT': return { x: dist, opacity: 0, rotate: 720, scale: 0.5 };
       }
    } else if (animType === 'ZOOM_OUT') {
       return { opacity: 0, scale: 0, rotate: 180 };
    } else if (animType === 'FADE_UP') {
       return { y: -50, opacity: 0, scale: 1.2 };
    }
    
    switch (dir) {
      case 'UP': return { y: -dist, opacity: 0 };
      case 'DOWN': return { y: dist, opacity: 0 };
      case 'LEFT': return { x: -dist, opacity: 0 };
      case 'RIGHT': return { x: dist, opacity: 0 };
    }
  };

  const theme = progress.equipped?.theme || 'default';
  
  let screenBgClass = "bg-[#FDFBF7] dark:bg-slate-950";
  let boardBgClass = "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800";
  let textClass = "text-slate-800 dark:text-slate-200";
  let gridBorderClass = "border-slate-100/50 dark:border-slate-800/50";
  
  if (theme === 'midnight') {
    screenBgClass = "bg-slate-900 dark:bg-black";
    boardBgClass = "bg-slate-800 dark:bg-slate-900 border-slate-700 dark:border-slate-800";
    textClass = "text-slate-100 dark:text-slate-300";
    gridBorderClass = "border-slate-700/50 dark:border-slate-800/50";
  } else if (theme === 'sakura') {
    screenBgClass = "bg-rose-50 dark:bg-rose-950";
    boardBgClass = "bg-white dark:bg-rose-900 border-rose-200 dark:border-rose-800";
    textClass = "text-rose-900 dark:text-rose-100";
    gridBorderClass = "border-rose-100/50 dark:border-rose-800/50";
  } else if (theme === 'forest') {
    screenBgClass = "bg-emerald-50 dark:bg-emerald-950";
    boardBgClass = "bg-white dark:bg-emerald-900 border-emerald-200 dark:border-emerald-800";
    textClass = "text-emerald-900 dark:text-emerald-100";
    gridBorderClass = "border-emerald-100/50 dark:border-emerald-800/50";
  } else if (theme === 'sunset') {
    screenBgClass = "bg-orange-50 dark:bg-orange-950";
    boardBgClass = "bg-white dark:bg-orange-900 border-orange-200 dark:border-orange-800";
    textClass = "text-orange-900 dark:text-orange-100";
    gridBorderClass = "border-orange-100/50 dark:border-orange-800/50";
  }

  return (
    <div className={cn("flex flex-col min-h-[100dvh] max-w-md mx-auto transition-colors duration-300 relative overflow-hidden", screenBgClass)}>
      {/* Header */}
      <div className="flex items-center justify-between p-6 z-10">
        <button 
          onClick={() => onNavigate('LEVEL_SELECT')}
          className="p-3 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-full transition-colors active:scale-95 -ml-3"
        >
          <ArrowLeft size={24} className={textClass} />
        </button>
        
        <div className={cn("font-bold text-lg tracking-widest", textClass)}>
          LEVEL {levelNumber}
        </div>
        
        <div className="flex items-center gap-1 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-full shadow-sm border border-slate-100 dark:border-slate-800">
          {Array.from({ length: levelData.hearts }).map((_, i) => (
            <Heart 
              key={i} 
              size={16} 
              className={cn(
                i < hearts ? "text-rose-500 fill-rose-500" : "text-slate-200 dark:text-slate-700 fill-slate-200 dark:fill-slate-700"
              )} 
            />
          ))}
        </div>
      </div>

      {/* Game Board */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div 
          className={cn("relative rounded-3xl shadow-sm border", boardBgClass)}
          style={{ width: boardSize, height: boardSize }}
        >
          {/* Grid lines (optional, for visual structure) */}
          <div className="absolute inset-0 grid" 
               style={{ 
                 gridTemplateColumns: `repeat(${levelData.gridSize}, 1fr)`,
                 gridTemplateRows: `repeat(${levelData.gridSize}, 1fr)`
               }}>
            {Array.from({ length: levelData.gridSize * levelData.gridSize }).map((_, i) => (
              <div key={i} className={cn("border-[0.5px] rounded-sm", gridBorderClass)}></div>
            ))}
          </div>

          {/* Path Guidance Highlight */}
          {longPressId && (
            <div className="absolute inset-0 z-0 pointer-events-none">
              {(() => {
                const arr = arrows.find(a => a.id === longPressId);
                if (!arr) return null;
                
                const isClear = isPathClear(arr, arrows, levelData.gridSize);
                
                // Calculate highlight rectangle based on direction
                let left = 0, top = 0, width = 0, height = 0;
                const margin = 8; // padding inside cell
                
                if (arr.direction === 'UP') {
                  left = arr.x * cellSize + margin;
                  width = cellSize - margin * 2;
                  top = 0;
                  height = (arr.y + 1) * cellSize - margin;
                } else if (arr.direction === 'DOWN') {
                  left = arr.x * cellSize + margin;
                  width = cellSize - margin * 2;
                  top = arr.y * cellSize + margin;
                  height = (levelData.gridSize - arr.y) * cellSize - margin * 2;
                } else if (arr.direction === 'LEFT') {
                  top = arr.y * cellSize + margin;
                  height = cellSize - margin * 2;
                  left = 0;
                  width = (arr.x + 1) * cellSize - margin;
                } else if (arr.direction === 'RIGHT') {
                  top = arr.y * cellSize + margin;
                  height = cellSize - margin * 2;
                  left = arr.x * cellSize + margin;
                  width = (levelData.gridSize - arr.x) * cellSize - margin * 2;
                }
                
                return (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={cn(
                      "absolute rounded-lg mix-blend-multiply",
                      isClear ? "bg-blue-100" : "bg-rose-100"
                    )}
                    style={{ left, top, width, height }}
                  />
                );
              })()}
            </div>
          )}

          {/* Arrows */}
          <AnimatePresence>
            {[...arrows, ...exitingArrows].map(arrow => {
              const isExiting = exitingArrows.some(a => a.id === arrow.id);
              const isHinted = hintArrowId === arrow.id;
              const isLongPressed = longPressId === arrow.id;
              const isError = errorArrowIds.includes(arrow.id);
              const isWaiting = waitingArrowIds.includes(arrow.id);
              
              return (
                <motion.div
                  key={arrow.id}
                  initial={{ 
                    x: arrow.x * cellSize, 
                    y: arrow.y * cellSize,
                    scale: 1,
                    opacity: 1
                  }}
                  animate={
                    isExiting 
                      ? { 
                          x: arrow.x * cellSize + (getExitAnimation(arrow.direction).x || 0),
                          y: arrow.y * cellSize + (getExitAnimation(arrow.direction).y || 0),
                          opacity: 0,
                          scale: 0.8
                        }
                      : isError
                        ? {
                            x: [arrow.x * cellSize, arrow.x * cellSize - 4, arrow.x * cellSize + 4, arrow.x * cellSize - 4, arrow.x * cellSize + 4, arrow.x * cellSize],
                            y: arrow.y * cellSize,
                            scale: 1,
                          }
                      : {
                          x: arrow.x * cellSize,
                          y: arrow.y * cellSize,
                          scale: isHinted ? [1, 1.1, 1] : isLongPressed ? 1.05 : 1,
                        }
                  }
                  transition={{
                    duration: isExiting ? 0.35 : isError ? 0.4 : 0.2,
                    ease: isExiting ? "easeIn" : "easeOut",
                    scale: isHinted ? { repeat: Infinity, duration: 1 } : {}
                  }}
                  className={cn(
                    "absolute flex items-center justify-center p-1.5",
                    isExiting ? "z-0" : isError || isHinted ? "z-20" : "z-10"
                  )}
                  style={{ 
                    width: cellSize, 
                    height: cellSize,
                  }}
                  onPointerDown={(e) => { e.preventDefault(); !isExiting && handlePointerDown(arrow); }}
                  onPointerUp={(e) => { e.preventDefault(); !isExiting && handlePointerUp(arrow); }}
                  onPointerLeave={(e) => { e.preventDefault(); !isExiting && handlePointerLeave(); }}
                  onContextMenu={(e) => e.preventDefault()} // prevent context menu on long press
                >
                  <div 
                    className={cn(
                      "w-full h-full relative cursor-pointer active:scale-95 transition-transform"
                    )}
                  >
                    {isHinted && (
                      <div className="absolute inset-0 bg-amber-400/20 rounded-lg animate-ping opacity-75"></div>
                    )}
                    <ArrowSvg 
                      length={arrow.length || 1} 
                      direction={arrow.direction} 
                      cellSize={cellSize} 
                      strokeColor={isError || isWaiting ? "#ef4444" : isHinted ? "#F59E0B" : isLongPressed ? "#3B82F6" : (progress.equipped?.color || "#574C43")} 
                    />
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="p-8 flex justify-between items-center z-10">
        <button 
          onClick={useHint}
          disabled={gameState !== 'playing' || adLoading}
          className={cn(
            "flex items-center gap-2 px-5 py-3 rounded-2xl font-semibold transition-all",
            totalHints > 0 && gameState === 'playing'
              ? "bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-900/50 active:scale-95" 
              : gameState === 'playing'
              ? "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-400 hover:bg-indigo-200 dark:hover:bg-indigo-900/50 active:scale-95"
              : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed"
          )}
        >
          {totalHints > 0 ? (
            <>
              <Lightbulb size={20} className={gameState === 'playing' ? "text-amber-500 dark:text-amber-400" : ""} />
              HINT <span className="opacity-60 text-sm ml-1">{totalHints}</span>
            </>
          ) : (
            <>
              <MonitorPlay size={20} className={gameState === 'playing' ? "text-indigo-500 dark:text-indigo-400" : ""} />
              {adLoading ? "LOADING..." : "AD HINT"}
            </>
          )}
        </button>

        <button 
          onClick={() => setGameState('paused')}
          disabled={gameState !== 'playing'}
          className="p-4 bg-white dark:bg-slate-900 shadow-sm border border-slate-100 dark:border-slate-800 rounded-2xl text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 active:scale-95 transition-all disabled:opacity-50"
        >
          <Pause size={20} fill="currentColor" />
        </button>
      </div>

      {/* Overlays */}
      <AnimatePresence>
        {gameState !== 'playing' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/40 dark:bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-8 rounded-3xl shadow-2xl w-full max-w-sm flex flex-col items-center text-center gap-6"
            >
              {gameState === 'completed' && (
                <>
                  <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-400 rounded-full flex items-center justify-center mb-2">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </div>
                  
                  {levelNumber === 100 ? (
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">CONGRATULATIONS!</h2>
                      <p className="text-slate-500 dark:text-slate-400 font-medium">ALL 100 LEVELS COMPLETED!</p>
                    </div>
                  ) : (
                    <div>
                      <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">LEVEL COMPLETE!</h2>
                      <p className="text-slate-500 dark:text-slate-400 font-medium">Board Cleared</p>
                    </div>
                  )}
                  
                  <div className="flex gap-2 my-2">
                    {[1, 2, 3].map(star => {
                      const earnedStars = mistakes === 0 ? 3 : mistakes <= Math.max(1, levelData.hearts - 1) ? 2 : 1;
                      return (
                        <Star 
                          key={star} 
                          size={32} 
                          className={cn(
                            star <= earnedStars ? "text-amber-400 fill-amber-400" : "text-slate-100 dark:text-slate-800 fill-slate-100 dark:fill-slate-800"
                          )} 
                        />
                      )
                    })}
                  </div>
                  
                  <div className="flex gap-4 w-full text-sm font-medium text-slate-500 dark:text-slate-400">
                    <div className="flex-1 bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 border border-slate-100 dark:border-slate-800/50">
                      Moves<br/><span className="text-lg text-slate-800 dark:text-slate-200 font-bold">{moves}</span>
                    </div>
                    <div className="flex-1 bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 border border-slate-100 dark:border-slate-800/50">
                      Mistakes<br/><span className="text-lg text-slate-800 dark:text-slate-200 font-bold">{mistakes}</span>
                    </div>
                  </div>

                  {earnedCoins !== null && earnedCoins > 0 && (
                    <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 font-bold px-4 py-2 rounded-full border border-amber-200/50 dark:border-amber-700/50">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <circle cx="12" cy="12" r="10" />
                        <text x="12" y="16" fontSize="12" fill="white" textAnchor="middle" fontWeight="bold">C</text>
                      </svg>
                      +{earnedCoins} Coins Earned!
                    </div>
                  )}

                  {levelNumber === 100 ? (
                    <>
                      <button 
                        onClick={() => onNavigate('LEVEL_SELECT')}
                        className="w-full py-4 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-2xl font-semibold text-lg mt-2 active:scale-95 transition-transform flex justify-center items-center gap-2"
                      >
                        ALL LEVELS
                      </button>
                      <button 
                        onClick={restartLevel}
                        className="text-slate-400 dark:text-slate-500 font-semibold hover:text-slate-600 dark:hover:text-slate-300 transition-colors py-2"
                      >
                        PLAY AGAIN
                      </button>
                    </>
                  ) : (
                    <>
                      <button 
                        onClick={handleNextLevel}
                        disabled={adLoading}
                        className="w-full py-4 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-2xl font-semibold text-lg mt-2 active:scale-95 transition-transform flex justify-center items-center gap-2 disabled:opacity-70 disabled:cursor-wait"
                      >
                        {adLoading ? "LOADING..." : "NEXT LEVEL"} <Play size={18} fill="currentColor" />
                      </button>
                      <button 
                        onClick={restartLevel}
                        className="text-slate-400 dark:text-slate-500 font-semibold hover:text-slate-600 dark:hover:text-slate-300 transition-colors py-2"
                      >
                        REPLAY
                      </button>
                    </>
                  )}
                </>
              )}

              {gameState === 'failed' && (
                <>
                  <div className="w-20 h-20 bg-rose-100 dark:bg-rose-900/30 text-rose-500 dark:text-rose-400 rounded-full flex items-center justify-center mb-2">
                    <Heart size={32} fill="currentColor" className="opacity-50" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">OUT OF HEARTS</h2>
                    <p className="text-slate-500 dark:text-slate-400 font-medium">Be careful not to tap blocked arrows.</p>
                  </div>
                  
                  {(progress.inventory?.globalHearts || 0) > 0 ? (
                    <button 
                      onClick={() => {
                        setProgress(prev => ({
                          ...prev,
                          inventory: {
                            ...prev.inventory!,
                            globalHearts: Math.max(0, prev.inventory!.globalHearts - 1)
                          }
                        }));
                        setHearts(1);
                        setGameState('playing');
                        setWaitingArrowIds([]);
                        setErrorArrowIds([]);
                      }}
                      className="w-full py-4 bg-rose-500 text-white rounded-2xl font-bold text-lg mt-4 active:scale-95 transition-transform flex justify-center items-center gap-2 shadow-lg shadow-rose-500/30"
                    >
                      <Heart size={18} fill="currentColor" /> REVIVE (1 Global Heart)
                    </button>
                  ) : (
                    <button 
                      onClick={async () => {
                        setAdLoading(true);
                        const success = await UnityAds.showRewarded();
                        setAdLoading(false);
                        if (success) {
                          setHearts(1);
                          setGameState('playing');
                          setWaitingArrowIds([]);
                          setErrorArrowIds([]);
                        }
                      }}
                      disabled={adLoading}
                      className="w-full py-4 bg-indigo-500 text-white rounded-2xl font-bold text-lg mt-4 active:scale-95 transition-transform flex justify-center items-center gap-2 shadow-lg shadow-indigo-500/30 disabled:opacity-70"
                    >
                      <MonitorPlay size={18} /> {adLoading ? "LOADING..." : "WATCH AD TO CONTINUE"}
                    </button>
                  )}
                  
                  <button 
                    onClick={restartLevel}
                    className="w-full py-4 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-2xl font-semibold text-lg mt-2 active:scale-95 transition-transform flex justify-center items-center gap-2"
                  >
                    <RotateCcw size={18} /> TRY AGAIN
                  </button>
                  <button 
                    onClick={() => onNavigate('LEVEL_SELECT')}
                    className="text-slate-400 dark:text-slate-500 font-semibold hover:text-slate-600 dark:hover:text-slate-300 transition-colors py-2"
                  >
                    BACK TO LEVELS
                  </button>
                </>
              )}

              {gameState === 'paused' && (
                <>
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-4 tracking-widest">PAUSED</h2>
                  
                  <div className="flex flex-col gap-3 w-full">
                    <button 
                      onClick={() => setGameState('playing')}
                      className="w-full py-4 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-2xl font-semibold text-lg active:scale-95 transition-transform"
                    >
                      RESUME
                    </button>
                    <button 
                      onClick={restartLevel}
                      className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-2xl font-semibold text-lg active:scale-95 transition-transform"
                    >
                      RESTART
                    </button>
                    <button 
                      onClick={() => onNavigate('LEVEL_SELECT')}
                      className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-rose-500 dark:text-rose-400 rounded-2xl font-semibold text-lg active:scale-95 transition-transform"
                    >
                      EXIT
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
