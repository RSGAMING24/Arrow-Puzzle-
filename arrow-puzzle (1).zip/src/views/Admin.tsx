import React, { useState, useEffect, useRef } from 'react';
import { ViewState } from '../App';
import { LevelData, Arrow, Direction } from '../types';
import { ArrowLeft, Plus, Save, Play, Trash2, Copy, AlertTriangle, CheckCircle2, Download, Upload } from 'lucide-react';
import { checkSolvability } from '../lib/gameLogic';
import { cn } from '../lib/utils';
import { ArrowSvg } from '../components/ArrowSvg';

interface AdminProps {
  levels: LevelData[];
  setLevels: (val: LevelData[] | ((prev: LevelData[]) => LevelData[])) => void;
  onNavigate: (v: ViewState, level?: number) => void;
}

export function Admin({ levels, setLevels, onNavigate }: AdminProps) {
  const [editingLevelId, setEditingLevelId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createLevel = () => {
    const newNumber = levels.length > 0 ? Math.max(...levels.map(l => l.number)) + 1 : 1;
    const newLevel: LevelData = {
      id: `level_${Date.now()}`,
      number: newNumber,
      gridSize: 4,
      difficulty: 'Easy',
      hearts: 3,
      hints: 3,
      coinReward: 5,
      status: 'Draft',
      arrows: []
    };
    setLevels(prev => [...prev, newLevel]);
    setEditingLevelId(newLevel.id);
  };

  const deleteLevel = (id: string) => {
    if (confirm('Are you sure you want to delete this level?')) {
      setLevels(prev => prev.filter(l => l.id !== id));
    }
  };

  const duplicateLevel = (level: LevelData) => {
    const newNumber = Math.max(...levels.map(l => l.number)) + 1;
    const newLevel: LevelData = {
      ...level,
      id: `level_${Date.now()}`,
      number: newNumber,
      status: 'Draft'
    };
    setLevels(prev => [...prev, newLevel]);
  };

  const exportLevels = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(levels, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", "arrow_puzzle_levels.json");
    dlAnchorElem.click();
  };

  const importLevels = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const json = JSON.parse(event.target?.result as string);
          if (Array.isArray(json)) {
            setLevels(json);
            alert("Levels imported successfully!");
          } else {
            alert("Invalid format: Expected an array of levels.");
          }
        } catch (err) {
          alert("Invalid JSON file");
        }
      };
      reader.readAsText(file);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (editingLevelId) {
    const levelToEdit = levels.find(l => l.id === editingLevelId);
    if (!levelToEdit) {
      setEditingLevelId(null);
      return null;
    }

    return (
      <LevelEditor 
        level={levelToEdit} 
        onSave={(updated) => {
          setLevels(prev => prev.map(l => l.id === updated.id ? updated : l));
        }}
        onBack={() => setEditingLevelId(null)}
        onPlayTest={() => { 
          onNavigate('GAME', levelToEdit.number);
        }}
      />
    );
  }

  return (
    <div className="flex flex-col min-h-[100dvh] max-w-5xl mx-auto p-8 bg-slate-50">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">ADMIN DASHBOARD</h1>
          <div className="flex gap-4 mt-2">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Total Levels</span>
              <span className="text-xl font-bold text-slate-700">{levels.length}</span>
            </div>
            <div className="h-8 w-px bg-slate-200"></div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Published</span>
              <span className="text-xl font-bold text-emerald-600">{levels.filter(l => l.status === 'Live').length}</span>
            </div>
            <div className="h-8 w-px bg-slate-200"></div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Drafts</span>
              <span className="text-xl font-bold text-amber-500">{levels.filter(l => l.status === 'Draft').length}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate('HOME')}
            className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-700 font-medium hover:bg-slate-50"
          >
            Exit Admin
          </button>
          
          <div className="h-8 w-px bg-slate-300 mx-1 my-auto"></div>
          
          <input type="file" accept=".json" className="hidden" ref={fileInputRef} onChange={importLevels} />
          <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50" title="Import JSON">
            <Upload size={18} />
          </button>
          <button onClick={exportLevels} className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50" title="Export JSON">
            <Download size={18} />
          </button>
          
          <button 
            onClick={createLevel}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 ml-2"
          >
            <Plus size={18} /> Create Level
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm">Level</th>
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm">Grid</th>
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm">Arrows</th>
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm">Difficulty</th>
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm">Status</th>
              <th className="px-6 py-4 font-semibold text-slate-600 text-sm text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {levels.sort((a, b) => a.number - b.number).map(level => (
              <tr key={level.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                <td className="px-6 py-4 font-medium text-slate-900">{level.number}</td>
                <td className="px-6 py-4 text-slate-600">{level.gridSize}x{level.gridSize}</td>
                <td className="px-6 py-4 text-slate-600">{level.arrows.length}</td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "px-2.5 py-1 rounded-full text-xs font-semibold",
                    level.difficulty === 'Easy' ? "bg-green-100 text-green-700" :
                    level.difficulty === 'Medium' ? "bg-amber-100 text-amber-700" :
                    level.difficulty === 'Hard' ? "bg-orange-100 text-orange-700" :
                    "bg-rose-100 text-rose-700"
                  )}>
                    {level.difficulty}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "px-2.5 py-1 rounded-full text-xs font-semibold",
                    level.status === 'Live' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"
                  )}>
                    {level.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                  <button onClick={() => setEditingLevelId(level.id)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg">Edit</button>
                  <button onClick={() => duplicateLevel(level)} className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg"><Copy size={18} /></button>
                  <button onClick={() => deleteLevel(level.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
            {levels.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">No levels found. Create one to get started.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LevelEditor({ level, onSave, onBack, onPlayTest }: { level: LevelData, onSave: (l: LevelData) => void, onBack: () => void, onPlayTest: () => void }) {
  const [edited, setEdited] = useState<LevelData>(level);
  const [selectedArrowId, setSelectedArrowId] = useState<string | null>(null);

  const isSolvable = checkSolvability(edited.arrows, edited.gridSize);

  const addArrow = (x: number, y: number) => {
    if (edited.arrows.some(a => a.x === x && a.y === y)) return; // Cell occupied
    
    const newArrow: Arrow = {
      id: `arrow_${Date.now()}`,
      x,
      y,
      direction: 'UP',
      length: 1
    };
    
    setEdited(prev => ({
      ...prev,
      arrows: [...prev.arrows, newArrow]
    }));
    setSelectedArrowId(newArrow.id);
  };

  const updateArrow = (id: string, updates: Partial<Arrow>) => {
    setEdited(prev => ({
      ...prev,
      arrows: prev.arrows.map(a => a.id === id ? { ...a, ...updates } : a)
    }));
  };

  const deleteArrow = (id: string) => {
    setEdited(prev => ({
      ...prev,
      arrows: prev.arrows.filter(a => a.id !== id)
    }));
    if (selectedArrowId === id) setSelectedArrowId(null);
  };

  return (
    <div className="flex flex-col min-h-[100dvh] max-w-6xl mx-auto p-6 bg-slate-50">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-200 rounded-full text-slate-600">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-2xl font-bold text-slate-900">Level {edited.number} Editor</h2>
        </div>
        <div className="flex items-center gap-4">
          <div className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold",
            isSolvable ? "bg-green-100 text-green-700" : "bg-rose-100 text-rose-700"
          )}>
            {isSolvable ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
            {isSolvable ? "Solvable" : "Unsolvable"}
          </div>
          <button 
            onClick={() => { onSave(edited); onPlayTest(); }}
            className="flex items-center gap-2 px-4 py-2 bg-slate-200 text-slate-800 rounded-lg font-medium hover:bg-slate-300"
          >
            <Play size={18} /> Play Test
          </button>
          <button 
            onClick={() => onSave(edited)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
          >
            <Save size={18} /> Save Level
          </button>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Editor Settings Sidebar */}
        <div className="w-80 flex flex-col gap-6">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col gap-4">
            <h3 className="font-bold text-slate-800 border-b pb-2">Level Settings</h3>
            
            <label className="flex flex-col gap-1 text-sm font-medium text-slate-600">
              Level Number (Locked)
              <input type="number" readOnly value={edited.number} className="p-2 border rounded-lg bg-slate-100 text-slate-500 cursor-not-allowed" />
            </label>
            
            <label className="flex flex-col gap-1 text-sm font-medium text-slate-600">
              Grid Size
              <select value={edited.gridSize} onChange={e => setEdited({...edited, gridSize: parseInt(e.target.value)})} className="p-2 border rounded-lg bg-slate-50">
                {[3, 4, 5, 6, 7, 8].map(s => <option key={s} value={s}>{s} x {s}</option>)}
              </select>
            </label>

            <label className="flex flex-col gap-1 text-sm font-medium text-slate-600">
              Difficulty
              <select value={edited.difficulty} onChange={e => setEdited({...edited, difficulty: e.target.value as any})} className="p-2 border rounded-lg bg-slate-50">
                <option value="Very Easy">Very Easy</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Medium/Hard">Medium/Hard</option>
                <option value="Hard">Hard</option>
                <option value="Very Hard">Very Hard</option>
                <option value="Expert">Expert</option>
                <option value="MASTER / EXTREME">MASTER / EXTREME</option>
              </select>
            </label>

            <label className="flex flex-col gap-1 text-sm font-medium text-slate-600">
              Coin Reward
              <input type="number" min="0" value={edited.coinReward || 0} onChange={e => setEdited({...edited, coinReward: parseInt(e.target.value) || 0})} className="p-2 border rounded-lg bg-slate-50" />
            </label>

            <label className="flex flex-col gap-1 text-sm font-medium text-slate-600">
              Status
              <select value={edited.status} onChange={e => setEdited({...edited, status: e.target.value as any})} className="p-2 border rounded-lg bg-slate-50">
                <option value="Draft">Draft</option>
                <option value="Live">Live</option>
              </select>
            </label>
          </div>

          {selectedArrowId && (
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col gap-4 border-l-4 border-l-blue-500">
              <h3 className="font-bold text-slate-800 border-b pb-2">Selected Arrow</h3>
              
              <div className="flex gap-2">
                {(['UP', 'DOWN', 'LEFT', 'RIGHT'] as Direction[]).map(dir => (
                  <button 
                    key={dir}
                    onClick={() => updateArrow(selectedArrowId, { direction: dir })}
                    className={cn(
                      "flex-1 p-2 border rounded-lg flex justify-center",
                      edited.arrows.find(a => a.id === selectedArrowId)?.direction === dir ? "bg-slate-800 text-white border-slate-800" : "bg-slate-50 hover:bg-slate-100 text-slate-600"
                    )}
                  >
                    {dir === 'UP' && '⬆️'}
                    {dir === 'DOWN' && '⬇️'}
                    {dir === 'LEFT' && '⬅️'}
                    {dir === 'RIGHT' && '➡️'}
                  </button>
                ))}
              </div>

              <label className="flex flex-col gap-1 text-sm font-medium text-slate-600 mt-2">
                Length
                <div className="flex gap-2 items-center">
                  <input 
                    type="range" 
                    min="1" 
                    max={edited.gridSize} 
                    value={edited.arrows.find(a => a.id === selectedArrowId)?.length || 1} 
                    onChange={e => updateArrow(selectedArrowId, { length: parseInt(e.target.value) })} 
                    className="flex-1"
                  />
                  <div className="text-center font-bold text-slate-800 bg-slate-100 px-3 py-1 rounded-md">
                    {edited.arrows.find(a => a.id === selectedArrowId)?.length || 1}
                  </div>
                </div>
              </label>

              <button 
                onClick={() => deleteArrow(selectedArrowId)}
                className="w-full py-2 mt-2 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-lg font-medium text-sm flex justify-center items-center gap-2"
              >
                <Trash2 size={16} /> Delete Arrow
              </button>
            </div>
          )}
        </div>

        {/* Board Canvas */}
        <div className="flex-1 flex flex-col items-center justify-center bg-[#FDFBF7] rounded-2xl shadow-inner border border-slate-200 p-8">
          <p className="text-slate-500 mb-6 font-medium text-sm">Click empty cell to add arrow. Click arrow to select.</p>
          
          <div 
            className="relative bg-white shadow-sm border border-slate-200"
            style={{ 
              width: edited.gridSize * 60,
              height: edited.gridSize * 60
            }}
          >
            {/* Grid lines */}
            <div className="absolute inset-0 grid" 
                 style={{ 
                   gridTemplateColumns: `repeat(${edited.gridSize}, 1fr)`,
                   gridTemplateRows: `repeat(${edited.gridSize}, 1fr)`
                 }}>
              {Array.from({ length: edited.gridSize * edited.gridSize }).map((_, i) => {
                const x = i % edited.gridSize;
                const y = Math.floor(i / edited.gridSize);
                
                return (
                  <div 
                    key={i}
                    onClick={() => addArrow(x, y)}
                    className="border-[0.5px] border-slate-200/50 hover:bg-blue-50/50 cursor-pointer"
                  />
                )
              })}
            </div>

            {/* Arrows */}
            {edited.arrows.map(arrow => (
              <div
                key={arrow.id}
                onClick={() => setSelectedArrowId(arrow.id)}
                className={cn(
                  "absolute flex items-center justify-center cursor-pointer z-10",
                  selectedArrowId === arrow.id ? "ring-2 ring-blue-500 rounded-lg bg-blue-50/20" : ""
                )}
                style={{ 
                  left: arrow.x * 60,
                  top: arrow.y * 60,
                  width: 60, 
                  height: 60,
                }}
              >
                <ArrowSvg 
                  length={arrow.length || 1} 
                  direction={arrow.direction} 
                  cellSize={60} 
                  strokeColor={selectedArrowId === arrow.id ? "#3B82F6" : "#574C43"} 
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
