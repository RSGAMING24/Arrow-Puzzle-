import React, { useState } from 'react';
import { ViewState } from '../App';
import { PlayerProgress, LevelData } from '../types';
import { Play, Settings, X, Sun, Moon, Monitor, Volume2, VolumeX, Calendar, ShoppingCart, LifeBuoy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MysteryGift } from '../components/MysteryGift';

interface HomeProps {
  onNavigate: (v: ViewState, level?: number) => void;
  progress: PlayerProgress;
  setProgress: React.Dispatch<React.SetStateAction<PlayerProgress>>;
  levels: LevelData[];
}

export function Home({ onNavigate, progress, setProgress, levels }: HomeProps) {
  const [logoError, setLogoError] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const maxLevel = levels.length > 0 ? Math.max(...levels.filter(l => l.status === 'Live').map(l => l.number)) : 100;
  const isAllCompleted = progress.currentLevel > maxLevel;
  const targetLevel = isAllCompleted ? maxLevel : progress.currentLevel;

  const updateSettings = (key: keyof PlayerProgress['settings'], value: any) => {
    setProgress(prev => ({
      ...prev,
      settings: { ...prev.settings, [key]: value }
    }));
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[100dvh] p-8 max-w-md mx-auto relative bg-[#FDFBF7] dark:bg-slate-950 transition-colors duration-300">
      <div className="w-full flex justify-between mt-2 z-10 relative items-center">
        <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-900/20 px-4 py-2 rounded-2xl border border-amber-200/50 dark:border-amber-700/50 shadow-sm">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className="text-amber-500">
            <circle cx="12" cy="12" r="10" />
            <text x="12" y="16.5" fontSize="12" fill="#FFF" textAnchor="middle" fontWeight="bold">C</text>
          </svg>
          <span className="text-amber-600 dark:text-amber-400 font-bold text-lg">{progress.coins || 0}</span>
        </div>

        <button 
          onClick={() => setIsSettingsOpen(true)}
          className="p-3 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-full transition-colors active:scale-95"
        >
          <Settings size={24} className="text-slate-500 dark:text-slate-400" />
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center w-full my-auto pb-16"
      >
        <div className="w-full flex justify-center mb-16 h-32 items-center">
           {!logoError ? (
             <img 
                 src="/logo.png" 
                 alt="Custom Logo" 
                 className="w-48 h-auto object-contain drop-shadow-sm dark:drop-shadow-none" 
                 onError={() => setLogoError(true)}
             />
           ) : (
             <div className="text-center">
               <div className="font-bold text-4xl tracking-widest text-slate-900 dark:text-slate-100 leading-tight">
                 ARROW
               </div>
               <div className="font-medium text-xl tracking-[0.2em] text-slate-500 dark:text-slate-400 mt-2">
                 PUZZLE
               </div>
             </div>
           )}
        </div>

        <div className="flex flex-col w-full gap-5 max-w-[280px] relative">
          <MysteryGift progress={progress} setProgress={setProgress} />

          <button 
            onClick={() => onNavigate('GAME', targetLevel)}
            className="w-full py-5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-2xl font-bold text-xl shadow-xl shadow-slate-900/20 dark:shadow-slate-100/10 hover:bg-slate-800 dark:hover:bg-white active:scale-95 transition-all flex justify-center items-center gap-3"
          >
            {isAllCompleted ? "PLAY AGAIN" : "PLAY"}
          </button>
          
          <button 
            onClick={() => onNavigate('LEVEL_SELECT')}
            className="w-full py-5 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-2 border-slate-200 dark:border-slate-800 rounded-2xl font-bold text-lg hover:bg-slate-50 dark:hover:bg-slate-800 active:scale-95 transition-all flex justify-center items-center gap-3"
          >
            LEVELS
          </button>
          
          <button 
            onClick={() => onNavigate('DAILY_REWARD')}
            className="w-full py-5 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 border-2 border-indigo-200 dark:border-indigo-800/50 rounded-2xl font-bold text-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/40 active:scale-95 transition-all flex justify-center items-center gap-3 mt-4"
          >
            <Calendar size={20} />
            DAILY REWARD
          </button>
          
          <button 
            onClick={() => onNavigate('SHOP')}
            className="w-full py-5 bg-rose-50 dark:bg-rose-900/20 text-rose-700 dark:text-rose-400 border-2 border-rose-200 dark:border-rose-800/50 rounded-2xl font-bold text-lg hover:bg-rose-100 dark:hover:bg-rose-900/40 active:scale-95 transition-all flex justify-center items-center gap-3 mt-2"
          >
            <ShoppingCart size={20} />
            SHOP
          </button>
        </div>
      </motion.div>

      <a 
        href="https://www.youtube.com/@RSGAMING2.4"
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm font-semibold text-slate-500/80 dark:text-slate-500 tracking-[0.1em] pb-4 cursor-pointer hover:opacity-80 active:scale-95 transition-all"
      >
        RS Gaming Official
      </a>

      <AnimatePresence>
        {isSettingsOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-slate-900/40 dark:bg-black/60 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl shadow-2xl p-6 relative flex flex-col gap-8 border border-slate-100 dark:border-slate-800"
            >
              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X size={20} />
              </button>

              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 text-center mt-2">Settings</h2>

              <div className="flex flex-col gap-6">
                <div className="flex flex-col gap-3">
                  <label className="text-xs font-bold text-slate-400 tracking-wider uppercase px-1">Theme</label>
                  <div className="flex gap-2 bg-slate-100 dark:bg-slate-950 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-800/50">
                    <button 
                      onClick={() => updateSettings('theme', 'Light')}
                      className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all ${progress.settings?.theme === 'Light' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-slate-100 font-medium' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                      <Sun size={18} />
                      <span className="text-xs">Day</span>
                    </button>
                    <button 
                      onClick={() => updateSettings('theme', 'Dark')}
                      className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all ${progress.settings?.theme === 'Dark' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-slate-100 font-medium' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                      <Moon size={18} />
                      <span className="text-xs">Night</span>
                    </button>
                    <button 
                      onClick={() => updateSettings('theme', 'System')}
                      className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all ${(!progress.settings?.theme || progress.settings?.theme === 'System') ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-slate-100 font-medium' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                      <Monitor size={18} />
                      <span className="text-xs">System</span>
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <label className="text-xs font-bold text-slate-400 tracking-wider uppercase px-1">Sound</label>
                  <div className="flex gap-2 bg-slate-100 dark:bg-slate-950 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-800/50">
                    <button 
                      onClick={() => updateSettings('sound', true)}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${(progress.settings?.sound ?? true) ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-slate-100 font-medium' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                      <Volume2 size={18} /> ON
                    </button>
                    <button 
                      onClick={() => updateSettings('sound', false)}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${!(progress.settings?.sound ?? true) ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-slate-100 font-medium' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                    >
                      <VolumeX size={18} /> OFF
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => onNavigate('SPIN')}
        className="fixed bottom-6 right-6 w-14 h-14 bg-amber-400 dark:bg-amber-500 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(251,191,36,0.6)] text-amber-950 dark:text-amber-900 active:scale-90 transition-transform z-10 group"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 flex items-center justify-center bg-gradient-to-tr from-amber-300 to-amber-500 dark:from-amber-400 dark:to-amber-600 rounded-full border border-amber-200 dark:border-amber-400 shadow-inner overflow-hidden"
        >
          {/* Subtle rotating glow/shine effect */}
          <div className="absolute inset-0 bg-[conic-gradient(from_0deg,transparent_0_270deg,rgba(255,255,255,0.6)_360deg)]"></div>
          
          <LifeBuoy size={26} strokeWidth={2.5} className="text-amber-900 drop-shadow-sm z-10 relative" />
        </motion.div>
        
        {/* Glow / Light effect outside the spinning element */}
        <div className="absolute inset-0 rounded-full shadow-[inset_0_0_15px_rgba(255,255,255,0.4)] pointer-events-none"></div>
        <div className="absolute inset-0 bg-white/30 dark:bg-white/10 rounded-full animate-ping opacity-50 pointer-events-none" style={{ animationDuration: '2s' }}></div>
        
        {/* Static text, always upright */}
        <div className="absolute -bottom-2 bg-amber-900 dark:bg-amber-100 text-amber-100 dark:text-amber-900 text-[9px] font-black tracking-widest px-2.5 py-0.5 rounded-full shadow-md z-20 whitespace-nowrap">
          SPIN
        </div>
      </button>
    </div>
  );
}
