import React from 'react';
import { ViewState } from '../App';
import { PlayerProgress, LevelData } from '../types';
import { ArrowLeft, Lock, Star } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface LevelSelectProps {
  onNavigate: (v: ViewState, level?: number) => void;
  progress: PlayerProgress;
  levels: LevelData[];
}

export function LevelSelect({ onNavigate, progress, levels }: LevelSelectProps) {
  const publishedLevels = levels.filter(l => l.status === 'Live').sort((a, b) => a.number - b.number);

  // Group levels into chunks of 20
  const groups: { title: string; levels: LevelData[] }[] = [];
  for (let i = 0; i < publishedLevels.length; i += 20) {
    groups.push({
      title: `LEVELS ${i + 1}-${Math.min(i + 20, publishedLevels.length)}`,
      levels: publishedLevels.slice(i, i + 20)
    });
  }

  return (
    <div className="flex flex-col min-h-[100dvh] p-4 max-w-md mx-auto bg-[#FDFBF7] dark:bg-slate-950 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6 pt-4 sticky top-0 bg-[#FDFBF7]/90 dark:bg-slate-950/90 backdrop-blur-md z-20 pb-4 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={() => onNavigate('HOME')}
          className="p-3 hover:bg-slate-200/50 dark:hover:bg-slate-800/50 rounded-full transition-colors active:scale-95"
        >
          <ArrowLeft size={24} className="text-slate-800 dark:text-slate-200" />
        </button>
        <h1 className="font-bold text-xl text-slate-900 dark:text-slate-100 tracking-widest pl-6">LEVELS</h1>
        <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-full border border-amber-200/50 dark:border-amber-700/50">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="text-amber-500">
            <circle cx="12" cy="12" r="10" />
            <text x="12" y="16.5" fontSize="12" fill="#FFF" textAnchor="middle" fontWeight="bold">C</text>
          </svg>
          <span className="text-amber-600 dark:text-amber-400 font-bold text-sm">{progress.coins || 0}</span>
        </div>
      </div>

      <div className="flex flex-col gap-10 pb-12 overflow-y-auto">
        {groups.map((group, gIndex) => (
          <div key={gIndex} className="flex flex-col gap-4">
            <h2 className="text-xs font-bold text-slate-400 tracking-[0.2em] uppercase px-2">
              {group.title}
            </h2>
            <div className="grid grid-cols-5 gap-3">
              {group.levels.map((level, i) => {
                const isUnlocked = progress.unlockedLevels.includes(level.number);
                const isCompleted = !!progress.completedLevels[level.number];
                const stars = progress.completedLevels[level.number]?.stars || 0;
                const isCurrent = progress.currentLevel === level.number;

                return (
                  <motion.button
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: (i % 20) * 0.02 }}
                    key={level.id}
                    onClick={() => isUnlocked && onNavigate('GAME', level.number)}
                    disabled={!isUnlocked}
                    className={cn(
                      "aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all",
                      isCurrent 
                        ? "bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-md active:scale-95" 
                        : isUnlocked 
                          ? "bg-white dark:bg-slate-900 shadow-sm border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 active:scale-95 text-slate-800 dark:text-slate-200" 
                          : "bg-slate-100/50 dark:bg-slate-900/50 border border-slate-200/50 dark:border-slate-800/50 cursor-not-allowed opacity-50 text-slate-400 dark:text-slate-600"
                    )}
                  >
                    {!isUnlocked ? (
                      <Lock size={16} />
                    ) : (
                      <>
                        <span className="text-lg font-bold">
                          {level.number.toString().padStart(2, '0')}
                        </span>
                        {isCompleted && (
                          <div className="flex gap-[1px] mt-0.5 absolute bottom-1.5">
                            {[1, 2, 3].map(star => (
                              <Star 
                                key={star} 
                                size={8} 
                                className={cn(
                                  star <= stars ? "text-amber-400 fill-amber-400" : (isCurrent ? "text-slate-700 dark:text-slate-300 fill-slate-700 dark:fill-slate-300" : "text-slate-200 dark:text-slate-700 fill-slate-200 dark:fill-slate-700")
                                )} 
                              />
                            ))}
                          </div>
                        )}
                      </>
                    )}
                  </motion.button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
