/**
 * Unity Ads Bridge for Native Android Integration
 * Unity Game ID: 6094029
 */

declare global {
  interface Window {
    // Injected by Android WebView natively
    AndroidUnityAds?: {
      initialize(gameId: string, testMode: boolean): void;
      showInterstitial(placementId: string): void;
      showRewarded(placementId: string): void;
      isReady(placementId: string): boolean;
    };
    // Callbacks triggered by Native Android code to update Web state
    onUnityAdFinished?: (placementId: string, result: 'COMPLETED' | 'SKIPPED' | 'FAILED') => void;
  }
}

export const AdConfig = {
  GAME_ID: '6094029',
  INTERSTITIAL_PLACEMENT: 'Interstitial_Android',
  REWARDED_PLACEMENT: 'Rewarded_Android',
  DAILY_SPIN_AD_LIMIT: 20,
};

export const UnityAds = {
  /**
   * Initializes the Unity Ads SDK via native bridge.
   * @param testMode Set to false for REAL/PRODUCTION ads.
   */
  initialize: (testMode: boolean = false) => {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      window.AndroidUnityAds.initialize(AdConfig.GAME_ID, testMode);
      console.log('Unity Ads Native Bridge initialized.');
    } else {
      console.log('Unity Ads Native Bridge not found (running in browser). Initialization skipped.');
    }
  },
  
  /**
   * Shows an Interstitial Ad and returns a Promise resolving when the ad is closed.
   */
  showInterstitial: (placementId: string = AdConfig.INTERSTITIAL_PLACEMENT): Promise<boolean> => {
    return new Promise((resolve) => {
      if (typeof window !== 'undefined' && window.AndroidUnityAds) {
        window.onUnityAdFinished = (finishedPlacement, result) => {
          if (finishedPlacement === placementId) {
            resolve(result === 'COMPLETED' || result === 'SKIPPED');
            window.onUnityAdFinished = undefined;
          }
        };
        window.AndroidUnityAds.showInterstitial(placementId);
      } else {
        console.log('Unity Ads Native Bridge not found. Interstitial ad unavailable in preview.');
        resolve(false);
      }
    });
  },
  
  /**
   * Shows a Rewarded Ad and returns a Promise that resolves to true if completed.
   */
  showRewarded: (placementId: string = AdConfig.REWARDED_PLACEMENT): Promise<boolean> => {
    return new Promise((resolve) => {
      if (typeof window !== 'undefined' && window.AndroidUnityAds) {
        // Define the global callback that Native Android will call when the ad finishes
        window.onUnityAdFinished = (finishedPlacement, result) => {
          if (finishedPlacement === placementId) {
            resolve(result === 'COMPLETED');
            // Cleanup callback
            window.onUnityAdFinished = undefined;
          }
        };
        window.AndroidUnityAds.showRewarded(placementId);
      } else {
        console.log('Unity Ads Native Bridge not found. Rewarded ad unavailable in preview.');
        resolve(false);
      }
    });
  },

  /**
   * Checks if an ad placement is ready natively.
   */
  isReady: (placementId: string): boolean => {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      return window.AndroidUnityAds.isReady(placementId);
    }
    // On web, native ads are not available
    return false;
  }
};
