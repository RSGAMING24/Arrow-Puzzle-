import { LevelData } from '../types';

export const defaultLevels: LevelData[] = [
  {
    "id": "level_1",
    "number": 1,
    "gridSize": 4,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_1788945506824_494",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506824_486",
        "x": 1,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945506824_631",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506823_367",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506824_30",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506824_379",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_2",
    "number": 2,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506824_250",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_1788945506824_507",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506824_507",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_1788945506824_717",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506824_183",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506824_388",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506824_146",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_3",
    "number": 3,
    "gridSize": 4,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_1788945506824_7",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506824_221",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_1788945506824_183",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506825_371",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506824_969",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506825_152",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_4",
    "number": 4,
    "gridSize": 4,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506825_325",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506825_519",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_1788945506825_98",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_1788945506825_477",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506825_837",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506825_751",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_5",
    "number": 5,
    "gridSize": 5,
    "difficulty": "Very Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 3,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_1788945506825_477",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506825_879",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_1788945506825_327",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506825_445",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506825_908",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506825_629",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506825_350",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_6",
    "number": 6,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945506826_949",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506825_756",
        "x": 2,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506825_232",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506825_737",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_1788945506825_484",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_1788945506826_190",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945506826_411",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506825_416",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_1788945506826_671",
        "x": 4,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506826_416",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_0_1788945506825_91",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506826_258",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_7",
    "number": 7,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506827_234",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506827_164",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_1788945506826_601",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_7_1788945506828_403",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_1788945506828_827",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506827_625",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506827_578",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506826_490",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506828_587",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506828_659",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_8",
    "number": 8,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_1788945506829_656",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_8_1788945506829_270",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506830_866",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_1788945506828_724",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945506829_439",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506828_213",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506828_521",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506828_104",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_1788945506828_642",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506828_760",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_9",
    "number": 9,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945506832_538",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506830_228",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506832_872",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506830_879",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506830_524",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506830_99",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506830_864",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_1788945506830_824",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_7_1788945506830_270",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506830_229",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_10",
    "number": 10,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_1788945506832_699",
        "x": 0,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506832_928",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_10_1788945506832_498",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945506832_390",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506832_287",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506832_652",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_3_1788945506832_113",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_7_1788945506832_234",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506832_773",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506832_571",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506832_227",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_11_1788945506833_800",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_11",
    "number": 11,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506833_915",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506833_620",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_1788945506833_230",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506833_639",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_9_1788945506833_821",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506833_299",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_7_1788945506833_521",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_1788945506833_8",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506833_978",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506833_113",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_12",
    "number": 12,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_1788945506833_713",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506833_278",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506833_103",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506833_551",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945506833_80",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_1788945506833_954",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506833_354",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506833_228",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506833_805",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945506833_142",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_13",
    "number": 13,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_1788945506833_823",
        "x": 0,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506834_714",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506834_645",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506833_6",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506834_361",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506834_776",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506834_337",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_1788945506834_475",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506834_308",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945506834_570",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_14",
    "number": 14,
    "gridSize": 5,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_1788945506834_583",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506834_747",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506834_239",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506834_315",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506834_988",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506834_373",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506834_756",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506834_381",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506834_850",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506834_455",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_15",
    "number": 15,
    "gridSize": 6,
    "difficulty": "Easy",
    "hearts": 3,
    "hints": 3,
    "coinReward": 5,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_1788945506834_625",
        "x": 4,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506834_986",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506834_876",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506834_768",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_11_1788945506834_974",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_6_1788945506834_572",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_1788945506834_570",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506834_249",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506834_965",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506834_523",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506834_885",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945506834_755",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_16",
    "number": 16,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945506835_778",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506835_697",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_1788945506836_117",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506835_855",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506834_176",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_2_1788945506834_846",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506836_906",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506835_736",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_11_1788945506835_527",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506834_3",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506835_974",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506835_491",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506835_447",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506836_808",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506834_210",
        "x": 1,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_17",
    "number": 17,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_1788945506837_727",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506836_210",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506836_55",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_5_1788945506836_747",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506837_2",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506836_531",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_10_1788945506837_919",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506837_709",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506836_168",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506836_426",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506836_876",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506836_837",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_13_1788945506837_677",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506836_186",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506836_477",
        "x": 0,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_18",
    "number": 18,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945506837_682",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506837_115",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_10_1788945506837_300",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506837_393",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506838_368",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_1788945506837_53",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506837_865",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_1788945506837_654",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506838_657",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506837_177",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506838_373",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506837_756",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_9_1788945506837_524",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945506837_449",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506837_944",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_19",
    "number": 19,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506839_200",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506839_467",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506839_630",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506838_148",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_1_1788945506838_505",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506838_842",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506838_862",
        "x": 5,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506838_849",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506838_469",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506838_150",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945506839_868",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506839_532",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506838_258",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_6_1788945506838_801",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945506838_503",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_20",
    "number": 20,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_1788945506839_647",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_1788945506840_468",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506839_30",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506839_952",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_5_1788945506839_705",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506839_956",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506839_614",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506839_214",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506839_683",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_12_1788945506840_761",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506839_22",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506839_177",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_1788945506839_333",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506840_590",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506839_469",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_21",
    "number": 21,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_1788945506840_808",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506840_497",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_1788945506840_326",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506840_392",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506840_46",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506840_852",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506840_117",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506841_902",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506840_641",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506840_761",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_1788945506840_402",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506840_210",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_22",
    "number": 22,
    "gridSize": 6,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_1788945506841_976",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506841_350",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506841_841",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945506841_831",
        "x": 2,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506841_511",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_1788945506841_863",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945506841_921",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506841_715",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506841_605",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506841_132",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506841_687",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506841_601",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945506841_953",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506841_529",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506841_148",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_23",
    "number": 23,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506841_543",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_7_1788945506842_678",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506842_658",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506842_420",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506841_481",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_1788945506842_144",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506842_172",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506841_819",
        "x": 2,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506841_860",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506842_111",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506841_275",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506842_343",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_24",
    "number": 24,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945506842_285",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_10_1788945506843_533",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506842_687",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506842_488",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_1788945506842_436",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506843_393",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506842_426",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506843_148",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506842_848",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506842_849",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_1788945506842_61",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506842_729",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_25",
    "number": 25,
    "gridSize": 5,
    "difficulty": "Medium",
    "hearts": 3,
    "hints": 3,
    "coinReward": 8,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945506843_883",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506843_848",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_10_1788945506843_676",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506843_955",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506843_930",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506843_616",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506843_710",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506843_598",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_6_1788945506843_472",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506843_73",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_1788945506843_512",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_2_1788945506843_269",
        "x": 3,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_26",
    "number": 26,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_1788945506843_629",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_1788945506844_361",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506844_941",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506844_748",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506844_841",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_7_1788945506843_462",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506844_748",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506844_578",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_15_1788945506845_118",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506843_525",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506843_213",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506843_883",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_16_1788945506845_759",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506843_202",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_1788945506843_634",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945506846_826",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506844_826",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506843_212",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_27",
    "number": 27,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945506846_446",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506846_413",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945506848_550",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945506847_690",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945506846_530",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_1788945506846_767",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506847_682",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506846_379",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506846_194",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506846_7",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506848_359",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_1788945506846_266",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506849_617",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945506847_162",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945506849_402",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506847_673",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506846_520",
        "x": 6,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506847_687",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506846_353",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506848_854",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506846_52",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 4
      }
    ]
  },
  {
    "id": "level_28",
    "number": 28,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945506850_37",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_17_1788945506852_428",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945506852_191",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506850_190",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506849_119",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506850_974",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506851_233",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506851_2",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506849_593",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_4_1788945506849_431",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506850_751",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_15_1788945506852_34",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506849_951",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_8_1788945506850_522",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506850_761",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_6_1788945506850_124",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_11_1788945506850_589",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506849_118",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_29",
    "number": 29,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_18_1788945506854_183",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506852_56",
        "x": 2,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506853_352",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_12_1788945506853_747",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506854_370",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945506853_445",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945506853_3",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506853_995",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506852_836",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506853_171",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_1788945506853_884",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_4_1788945506852_832",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506852_614",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_2_1788945506852_657",
        "x": 0,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506853_915",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506853_47",
        "x": 4,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506853_827",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506853_172",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_19_1788945506854_995",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506853_559",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506854_14",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_30",
    "number": 30,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506854_521",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506854_839",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506855_681",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506854_975",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506854_709",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945506855_4",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506854_94",
        "x": 4,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506857_66",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506854_533",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506854_843",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_3_1788945506854_905",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_20_1788945506858_718",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506854_461",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_15_1788945506855_235",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506854_422",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506854_634",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506854_524",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506854_839",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506854_932",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506854_920",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506856_858",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_31",
    "number": 31,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_1788945506860_123",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_1788945506862_983",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506862_654",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506859_334",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945506858_768",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506858_61",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506861_660",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506858_222",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945506859_140",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506858_343",
        "x": 2,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506860_439",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506858_535",
        "x": 4,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_1788945506861_613",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506859_130",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506859_835",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506860_556",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506858_367",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_5_1788945506858_936",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_32",
    "number": 32,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945506862_479",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506862_610",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506862_989",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506862_945",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_1_1788945506862_337",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506862_39",
        "x": 4,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506862_330",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_5_1788945506862_454",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506863_49",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506862_646",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945506862_229",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506862_746",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506863_12",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506863_492",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506862_226",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506862_780",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_1788945506863_570",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506862_412",
        "x": 4,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_33",
    "number": 33,
    "gridSize": 6,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_1788945506863_565",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506863_367",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506863_271",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506863_775",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506863_886",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506863_984",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506863_282",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_1788945506863_251",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506863_101",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945506864_543",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506863_788",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506863_772",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_7_1788945506863_726",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506863_581",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506864_313",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506863_679",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506863_741",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506863_494",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_34",
    "number": 34,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_1788945506864_211",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506864_430",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_14_1788945506864_108",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945506865_194",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506864_150",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506864_403",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506864_339",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506864_120",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945506864_254",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_3_1788945506864_223",
        "x": 5,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506865_54",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506864_483",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506864_859",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506864_968",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506864_163",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506864_297",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506864_8",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_17_1788945506865_375",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_20_1788945506865_933",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_1788945506864_768",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506864_447",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_35",
    "number": 35,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506865_273",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506865_715",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506865_821",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506865_597",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506866_444",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506865_677",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_16_1788945506866_401",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945506865_720",
        "x": 6,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506865_119",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506865_91",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506865_118",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_18_1788945506866_906",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506866_583",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506865_309",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506865_633",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945506866_415",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506865_553",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506865_437",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_14_1788945506865_228",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_1788945506865_952",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506865_331",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      }
    ]
  },
  {
    "id": "level_36",
    "number": 36,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506867_137",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506866_970",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_1788945506867_656",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506867_451",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506867_971",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945506867_101",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506866_515",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_16_1788945506867_75",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506867_117",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506867_235",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506867_907",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506867_66",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506867_277",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506867_771",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506867_919",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506867_492",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506867_878",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506867_537",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506867_488",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506867_892",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_6_1788945506867_170",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_37",
    "number": 37,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_1788945506867_73",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_11_1788945506868_896",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506868_673",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506867_311",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_1788945506867_306",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_14_1788945506868_797",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945506868_554",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506868_713",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_1788945506867_633",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506867_588",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_1788945506868_719",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506867_64",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506868_444",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506867_218",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506867_164",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506868_928",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_1788945506868_964",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506868_410",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_15_1788945506868_44",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506867_298",
        "x": 5,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506867_118",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_38",
    "number": 38,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945506868_631",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506868_155",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506868_776",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506868_717",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_1788945506868_434",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506869_341",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506868_279",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506868_464",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506868_615",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506870_547",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945506870_248",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506868_617",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506868_561",
        "x": 3,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506868_109",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_1_1788945506868_238",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_17_1788945506869_709",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945506868_96",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_16_1788945506869_152",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506869_183",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506869_879",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506868_129",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_39",
    "number": 39,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_17_1788945506870_200",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506870_55",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945506870_497",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506870_286",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506870_487",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_15_1788945506870_590",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506870_51",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_1788945506870_34",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506870_868",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506871_982",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506870_696",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945506870_619",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_18_1788945506871_250",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506870_781",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506870_937",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945506870_225",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506870_596",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506870_76",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_14_1788945506870_910",
        "x": 4,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506870_236",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506871_133",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_40",
    "number": 40,
    "gridSize": 7,
    "difficulty": "Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 10,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_11_1788945506872_455",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506871_944",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_12_1788945506872_334",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_5_1788945506871_404",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506872_977",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506872_151",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506872_398",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506871_648",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_1788945506871_433",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506871_20",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506871_918",
        "x": 5,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945506872_707",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_1788945506872_871",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506872_399",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_1788945506871_976",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506872_858",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506871_120",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_3_1788945506871_893",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506871_507",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_1788945506872_557",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506871_591",
        "x": 4,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_41",
    "number": 41,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_7_1788945506872_835",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_4_1788945506872_768",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506872_421",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_1788945506872_783",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506873_391",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506872_81",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_1788945506873_704",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_1788945506872_312",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506873_428",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506873_33",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506873_215",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506872_459",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506872_937",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945506874_187",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506873_569",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506872_340",
        "x": 5,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506872_614",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506872_404",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_21_1788945506873_482",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945506873_26",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506873_77",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506874_686",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506872_891",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506873_821",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_42",
    "number": 42,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_18_1788945506874_956",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506874_597",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506874_696",
        "x": 2,
        "y": 6,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506874_374",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_1788945506874_85",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_1788945506874_475",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_1788945506874_273",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_20_1788945506875_682",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506876_959",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506874_671",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506874_799",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506874_121",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945506874_472",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_15_1788945506874_810",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_23_1788945506875_778",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506876_797",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506874_42",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506875_933",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506876_1",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945506874_784",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506874_646",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945506876_298",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506874_603",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506874_800",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506874_622",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506874_590",
        "x": 2,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_1788945506875_451",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506874_633",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_43",
    "number": 43,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_1788945506876_454",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_7_1788945506876_281",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506876_296",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506876_674",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506876_804",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506876_244",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_1788945506879_538",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945506876_38",
        "x": 7,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506878_881",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945506876_85",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945506878_274",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506878_174",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506876_606",
        "x": 7,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_1788945506876_603",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_23_1788945506877_524",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945506877_278",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506877_978",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945506876_17",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_16_1788945506876_264",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506876_957",
        "x": 0,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_20_1788945506877_879",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_1788945506876_755",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506876_758",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506877_419",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506877_61",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506876_421",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_1788945506876_458",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_14_1788945506876_587",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_44",
    "number": 44,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_1788945506881_129",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506880_640",
        "x": 3,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506879_479",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506879_934",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506879_741",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945506879_162",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_0_1788945506879_866",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506879_643",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506879_184",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_13_1788945506879_511",
        "x": 5,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506879_848",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506879_718",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506880_797",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506880_861",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506879_403",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506879_336",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506879_230",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506879_140",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945506879_32",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506879_947",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945506879_421",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945506880_830",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506881_907",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506879_637",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_45",
    "number": 45,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_12_1788945506881_774",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945506881_398",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506881_878",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506881_886",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506881_485",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506881_100",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506881_847",
        "x": 4,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506882_553",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506881_513",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506881_315",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506881_23",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506881_388",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945506881_905",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506881_477",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506881_271",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506881_58",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_13_1788945506881_841",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945506882_860",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506881_670",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506881_109",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506881_722",
        "x": 6,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506881_269",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506881_351",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506882_269",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506881_57",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506881_233",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945506881_71",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_1788945506881_296",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_46",
    "number": 46,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_1788945506885_936",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506883_805",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506884_21",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506882_424",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_13_1788945506883_99",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945506883_730",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506883_831",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506883_244",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506882_7",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506882_707",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945506883_754",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_3_1788945506882_460",
        "x": 5,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_1788945506882_204",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945506885_225",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506882_899",
        "x": 2,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506882_218",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506883_407",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506883_365",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_2_1788945506882_774",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_9_1788945506883_839",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506883_21",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_21_1788945506885_392",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506882_805",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_14_1788945506883_658",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_47",
    "number": 47,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_1788945506886_954",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506886_524",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506885_206",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506885_240",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_27_1788945506888_279",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506885_334",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_1788945506886_668",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506886_405",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506886_218",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506885_718",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506885_810",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_26_1788945506887_666",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506885_30",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506885_809",
        "x": 7,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506885_753",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506885_910",
        "x": 0,
        "y": 6,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_1788945506886_104",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506885_155",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_1788945506885_459",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_17_1788945506885_897",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945506885_49",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_1788945506885_910",
        "x": 3,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_1788945506886_443",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506885_243",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506885_191",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945506886_376",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506885_297",
        "x": 2,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_1788945506885_926",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_48",
    "number": 48,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_1788945506889_628",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_1788945506889_362",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_1788945506888_184",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_1788945506888_470",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506888_591",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_23_1788945506889_755",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506889_954",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945506888_596",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506888_364",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506889_425",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_1788945506889_4",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945506889_782",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_1788945506888_805",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945506888_491",
        "x": 7,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506888_410",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_20_1788945506889_51",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_7_1788945506888_531",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506888_927",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506888_804",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506888_575",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945506889_421",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506889_383",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506889_773",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506889_608",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506888_44",
        "x": 1,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506889_24",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506888_986",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506888_250",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_49",
    "number": 49,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_1788945506891_74",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_1788945506889_751",
        "x": 4,
        "y": 5,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_19_1788945506890_948",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_1788945506889_421",
        "x": 2,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506889_941",
        "x": 6,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_1788945506890_255",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506889_887",
        "x": 4,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506889_466",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_27_1788945506893_696",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945506891_281",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506889_450",
        "x": 3,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945506889_520",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_5_1788945506889_24",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506892_588",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945506892_761",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_1788945506890_689",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_1788945506892_110",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506890_138",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506889_689",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506890_413",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506889_83",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_20_1788945506890_713",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945506890_688",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_16_1788945506890_680",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506891_390",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506889_989",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506889_296",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506889_268",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_50",
    "number": 50,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_2_1788945506893_365",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_24_1788945506894_522",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506893_281",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_17_1788945506893_872",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506893_20",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_23_1788945506894_335",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506894_688",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945506893_225",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506893_683",
        "x": 6,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945506893_71",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_27_1788945506896_46",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_1788945506893_321",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506894_912",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506893_978",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506895_69",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945506894_499",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506893_652",
        "x": 7,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506893_369",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506893_834",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506894_752",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506893_79",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506893_496",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945506893_777",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506893_937",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_10_1788945506893_808",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506893_888",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945506893_53",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506895_499",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_51",
    "number": 51,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_1788945506896_577",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_1788945506896_705",
        "x": 6,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506898_392",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_1788945506896_487",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_1_1788945506896_342",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506896_39",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506896_128",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945506896_476",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945506896_108",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_24_1788945506897_288",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506896_592",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506896_180",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506896_854",
        "x": 3,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506896_73",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945506897_339",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945506896_588",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_1788945506896_261",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_1788945506898_463",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506897_535",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506896_972",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_13_1788945506896_884",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_1788945506896_305",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506896_637",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_12_1788945506896_393",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_22_1788945506897_657",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_14_1788945506896_168",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506896_45",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506896_153",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      }
    ]
  },
  {
    "id": "level_52",
    "number": 52,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_1788945506898_540",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_20_1788945506899_796",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506898_294",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506898_742",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_1788945506899_790",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_1_1788945506898_973",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945506900_836",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506898_339",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945506898_414",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506898_810",
        "x": 3,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506899_763",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506899_752",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506899_465",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506898_708",
        "x": 3,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_15_1788945506899_472",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506898_69",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945506899_925",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506899_85",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506898_376",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_5_1788945506898_707",
        "x": 1,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945506899_578",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_14_1788945506899_485",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506899_867",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945506899_781",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_53",
    "number": 53,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_17_1788945506901_570",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506900_274",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_10_1788945506900_884",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506900_836",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506904_207",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506900_198",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_6_1788945506900_160",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506900_469",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506900_705",
        "x": 4,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506900_852",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945506904_535",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945506901_369",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945506900_958",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506900_780",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_1788945506900_338",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506906_686",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506901_216",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506900_330",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506900_968",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_20_1788945506901_231",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506900_409",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945506906_595",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506902_571",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506902_93",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506900_882",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_1788945506900_539",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_1788945506902_105",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506900_325",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      }
    ]
  },
  {
    "id": "level_54",
    "number": 54,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_1788945506907_425",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506907_186",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506907_91",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506906_560",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_16_1788945506906_606",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506906_129",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945506906_671",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506906_77",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506906_624",
        "x": 3,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506906_758",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945506908_531",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506906_667",
        "x": 6,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_1788945506907_780",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506906_243",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506906_128",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506906_335",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_9_1788945506906_744",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506906_873",
        "x": 4,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945506906_444",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_1788945506906_253",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506906_41",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506906_344",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506906_525",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_1_1788945506906_653",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_55",
    "number": 55,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_9_1788945506908_492",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945506910_955",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945506908_379",
        "x": 2,
        "y": 1,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_1788945506908_103",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945506909_126",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506908_49",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506908_380",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506908_684",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_18_1788945506909_763",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506911_304",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506908_314",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_17_1788945506908_994",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506908_956",
        "x": 3,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506908_761",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506909_583",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506908_352",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506908_166",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_1788945506908_470",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_1788945506908_145",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506908_88",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_1788945506908_209",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506908_358",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506908_502",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945506914_456",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_56",
    "number": 56,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945506914_814",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506915_357",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945506914_712",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945506914_990",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506916_604",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945506915_740",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506914_828",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945506914_925",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506914_222",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_23_1788945506918_193",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506914_231",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506915_38",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506914_271",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945506914_732",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_1788945506914_444",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506914_95",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506914_490",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506914_180",
        "x": 3,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506914_875",
        "x": 5,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506914_945",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_1788945506914_950",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506914_304",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506914_676",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945506916_126",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_57",
    "number": 57,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_1788945506919_143",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506918_147",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_15_1788945506918_380",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945506918_69",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_27_1788945506921_958",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506918_299",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945506918_603",
        "x": 2,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_1788945506918_502",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945506921_845",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506919_710",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_1788945506918_698",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945506918_534",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506920_609",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506918_575",
        "x": 2,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945506919_19",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_3_1788945506918_521",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945506921_494",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506918_195",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_8_1788945506918_378",
        "x": 6,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506918_302",
        "x": 6,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506918_673",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_9_1788945506918_870",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506918_689",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_21_1788945506920_921",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506918_403",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_1788945506919_771",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945506921_911",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945506921_131",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_58",
    "number": 58,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_1_1788945506921_886",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_19_1788945506922_990",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506921_343",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_25_1788945506925_759",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506921_581",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_26_1788945506925_529",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506922_853",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_5_1788945506921_180",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506924_76",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506926_275",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945506921_50",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_1788945506921_931",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506921_408",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945506921_637",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945506923_897",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506921_566",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506921_124",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_17_1788945506922_920",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506921_924",
        "x": 7,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506921_151",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506922_593",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_1788945506924_504",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506921_808",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_7_1788945506921_763",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506922_805",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_1788945506921_572",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_23_1788945506924_829",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506921_836",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_59",
    "number": 59,
    "gridSize": 7,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_1788945506927_829",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506926_37",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506926_829",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_16_1788945506926_571",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506926_684",
        "x": 5,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506929_657",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506926_368",
        "x": 5,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506926_569",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506926_30",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506926_424",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945506926_899",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_1788945506926_494",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_1788945506929_313",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506926_924",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_1788945506927_260",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945506926_722",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_7_1788945506926_362",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506926_135",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_6_1788945506926_406",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506926_878",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_17_1788945506926_535",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_20_1788945506928_993",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506926_894",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_1788945506929_408",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_60",
    "number": 60,
    "gridSize": 8,
    "difficulty": "Very Hard",
    "hearts": 3,
    "hints": 3,
    "coinReward": 15,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_3_1788945506929_322",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945506929_677",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506929_722",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_2_1788945506929_19",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506929_92",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_6_1788945506929_716",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506929_205",
        "x": 1,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506929_357",
        "x": 6,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506930_821",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506929_223",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_23_1788945506930_211",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_1788945506929_790",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_1788945506929_245",
        "x": 6,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506929_933",
        "x": 6,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506929_172",
        "x": 1,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506929_459",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506929_504",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945506930_603",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945506929_135",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506929_109",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_14_1788945506929_779",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506931_334",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_25_1788945506930_732",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945506931_632",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506929_946",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506929_595",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_21_1788945506930_883",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945506929_215",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_61",
    "number": 61,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_1788945506931_379",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_18_1788945506933_502",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_1788945506931_132",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_9_1788945506931_940",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_1788945506945_181",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506932_433",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506931_843",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_24_1788945506935_302",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945506933_586",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945506931_723",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_1788945506931_579",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945506931_205",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_16_1788945506932_552",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506933_388",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506931_727",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_2_1788945506931_329",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_0_1788945506931_931",
        "x": 0,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506932_234",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506933_666",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_20_1788945506933_17",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506932_194",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_1788945506931_988",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_30_1788945506944_951",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506933_704",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945506933_515",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506931_418",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506931_235",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_62",
    "number": 62,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_14_1788945506945_674",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_1788945506955_432",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_1788945506947_117",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506945_61",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945506945_494",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506945_61",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_1788945506952_467",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506945_126",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_24_1788945506949_798",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506945_494",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506945_62",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_3_1788945506945_448",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_5_1788945506945_340",
        "x": 6,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945506945_163",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_19_1788945506946_14",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506945_104",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_1788945506946_268",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_1788945506957_318",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506947_534",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506945_15",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_1788945506947_507",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506946_414",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945506945_451",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_1788945506956_413",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506945_666",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506946_594",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_1788945506945_90",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_25_1788945506950_444",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506945_529",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945506946_961",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_63",
    "number": 63,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945506957_29",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506957_707",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506957_661",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945506957_622",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506961_904",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945506957_764",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_1788945506964_426",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945506957_384",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506957_99",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_23_1788945506959_940",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945506957_703",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_1788945506957_373",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_5_1788945506957_453",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945506962_293",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945506958_859",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945506957_427",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_1788945506964_86",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_1788945506963_594",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_1788945506963_62",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945506962_170",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506957_747",
        "x": 4,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506957_699",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945506958_669",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506957_518",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_1788945506957_15",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_17_1788945506957_561",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506958_588",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506957_784",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_1788945506964_327",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506957_292",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506957_354",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_6_1788945506957_53",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_64",
    "number": 64,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_14_1788945506965_590",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_1788945506965_897",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_22_1788945506967_607",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945506969_703",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945506969_92",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945506966_420",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_23_1788945506967_574",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_21_1788945506967_744",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506965_996",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945506965_527",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945506965_80",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506965_323",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945506965_110",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_5_1788945506965_599",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945506968_564",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_1788945506969_902",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506965_863",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_11_1788945506965_622",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_1788945506971_66",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506965_397",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_19_1788945506966_25",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945506965_400",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945506965_320",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_20_1788945506966_32",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506966_460",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945506965_193",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_16_1788945506965_335",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945506965_689",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_10_1788945506965_947",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      }
    ]
  },
  {
    "id": "level_65",
    "number": 65,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_16_1788945506975_571",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945506975_50",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506975_948",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_20_1788945506976_208",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945506976_242",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_27_1788945506978_334",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_8_1788945506975_633",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_21_1788945506976_890",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945506977_168",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945506975_833",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945506975_564",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945506977_253",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_1788945506983_190",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945506976_69",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_15_1788945506975_562",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506975_768",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_30_1788945506982_132",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945506975_884",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945506975_807",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506975_311",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945506976_314",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945506975_536",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_29_1788945506980_213",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945506975_694",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506975_138",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945506978_223",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945506975_835",
        "x": 2,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945506975_736",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945506975_316",
        "x": 5,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945506977_660",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_2_1788945506975_561",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_66",
    "number": 66,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506984_556",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_1788945506984_597",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945506984_364",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945506985_758",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506983_928",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945506985_560",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945506986_921",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945506985_758",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945506983_763",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_1788945506994_852",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945506988_706",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945506983_412",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_27_1788945506990_925",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945506983_5",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945506983_944",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945506983_864",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_24_1788945506988_320",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_0_1788945506983_89",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_2_1788945506983_762",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_19_1788945506985_265",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_15_1788945506984_128",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_1788945506984_470",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_11_1788945506983_475",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945506989_370",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945506983_174",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_5_1788945506983_650",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_20_1788945506985_459",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945506983_474",
        "x": 3,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_67",
    "number": 67,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945506997_697",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_23_1788945507002_953",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945506997_764",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945506997_720",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945506998_161",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945506997_396",
        "x": 7,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945506997_594",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945506997_891",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_8_1788945506997_143",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_10_1788945506997_753",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945506998_565",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945507001_569",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507000_204",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945506997_72",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507004_467",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945506999_216",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945506997_143",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_9_1788945506997_132",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945506997_158",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_15_1788945506997_455",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507000_485",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945506997_50",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_3_1788945506997_998",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507000_699",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945506997_852",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      }
    ]
  },
  {
    "id": "level_68",
    "number": 68,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945507015_657",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_13_1788945507015_388",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945507015_229",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_0_1788945507015_584",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_7_1788945507015_795",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_6_1788945507015_296",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507016_772",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945507015_895",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507015_153",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_18_1788945507016_299",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_23_1788945507018_517",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507020_600",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945507015_615",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507015_930",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_1788945507015_483",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507015_362",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_1_1788945507015_781",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_22_1788945507018_77",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945507016_41",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507015_549",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_3_1788945507015_348",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_27_1788945507021_919",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507016_805",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_25_1788945507020_599",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_29_1788945507023_634",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507016_17",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_21_1788945507017_227",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_9_1788945507015_200",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_69",
    "number": 69,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_1788945507028_296",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945507027_870",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507026_92",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_17_1788945507027_419",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507026_85",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_15_1788945507027_851",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_29_1788945507032_127",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_1788945507031_444",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_1788945507028_492",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507026_855",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_1_1788945507026_343",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507026_12",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_1788945507034_285",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507026_541",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_0_1788945507026_335",
        "x": 5,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507027_523",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945507026_889",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507028_935",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507027_992",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945507026_144",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_14_1788945507027_72",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507029_814",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_1788945507030_167",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945507026_816",
        "x": 2,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507030_258",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507026_680",
        "x": 6,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945507026_462",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_2_1788945507026_352",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_23_1788945507028_637",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_3_1788945507026_19",
        "x": 7,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507029_990",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_70",
    "number": 70,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_1788945507038_105",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_1788945507045_421",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507042_674",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507048_537",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507037_108",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945507037_404",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507037_476",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507040_34",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507037_719",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945507037_250",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_10_1788945507037_377",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_23_1788945507041_76",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507037_801",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507038_64",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945507039_99",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507037_675",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945507037_371",
        "x": 1,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507037_391",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507037_21",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945507037_759",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_4_1788945507037_764",
        "x": 1,
        "y": 4,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_2_1788945507037_791",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_17_1788945507037_832",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_1_1788945507037_186",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_28_1788945507045_321",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_1788945507042_369",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507037_913",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_27_1788945507044_320",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945507038_361",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507037_554",
        "x": 5,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_26_1788945507043_631",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_71",
    "number": 71,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945507048_543",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_10_1788945507048_85",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507049_257",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507049_558",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507051_897",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_7_1788945507048_499",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_26_1788945507051_671",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507048_907",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_25_1788945507051_239",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507048_273",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507048_805",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_30_1788945507054_710",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507048_381",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507048_433",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_15_1788945507048_563",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_1788945507048_239",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507048_799",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_9_1788945507048_74",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507048_886",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_18_1788945507048_810",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507048_21",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507048_951",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_13_1788945507048_557",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507048_748",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_1788945507049_727",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507048_5",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507050_472",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_20_1788945507049_902",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507049_773",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_1788945507051_508",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_72",
    "number": 72,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_1788945507057_229",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507058_298",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507061_45",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507056_56",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507057_186",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507057_708",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507059_217",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507056_383",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945507056_572",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507056_259",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_17_1788945507057_991",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507056_709",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_2_1788945507056_354",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507056_101",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_0_1788945507056_714",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_26_1788945507059_328",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507056_627",
        "x": 2,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507057_917",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507056_655",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507057_326",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_1788945507061_859",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945507058_767",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945507056_684",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_29_1788945507061_97",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507056_804",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507058_469",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945507056_490",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_1788945507059_222",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507056_633",
        "x": 1,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507056_401",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507056_147",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_16_1788945507057_977",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_73",
    "number": 73,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_21_1788945507063_755",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507067_353",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507062_226",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507062_618",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507070_297",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_1788945507066_853",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507062_703",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_20_1788945507062_580",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945507062_414",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945507062_394",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507064_625",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945507063_288",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507062_231",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507062_798",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507062_104",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_2_1788945507062_830",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_25_1788945507064_495",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945507063_97",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_12_1788945507062_806",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507062_806",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945507062_593",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_5_1788945507062_80",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_7_1788945507062_457",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507062_928",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945507062_692",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_1788945507065_523",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507062_684",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_1788945507063_361",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507062_468",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_18_1788945507062_377",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_4_1788945507062_957",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_74",
    "number": 74,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945507070_747",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_14_1788945507070_356",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507072_24",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507070_9",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507070_801",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_1788945507075_494",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507070_10",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507070_613",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_3_1788945507070_852",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_1788945507073_743",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945507074_382",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507070_448",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945507070_520",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945507070_504",
        "x": 4,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_1788945507072_256",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507070_559",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507072_783",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507071_136",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507071_241",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507070_369",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507072_286",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945507070_499",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507071_443",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_2_1788945507070_89",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_9_1788945507070_434",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_23_1788945507073_842",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507070_285",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_1788945507076_803",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945507073_210",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_75",
    "number": 75,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_1788945507081_180",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_2_1788945507080_663",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_30_1788945507084_433",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507084_209",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507080_405",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507080_359",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_12_1788945507080_964",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_26_1788945507082_992",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507083_76",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945507080_467",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507080_584",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_1788945507081_609",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507081_409",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945507080_666",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507080_589",
        "x": 0,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507080_688",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_1788945507080_11",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_1788945507081_834",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507080_750",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945507080_795",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_1788945507085_731",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945507080_940",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507080_98",
        "x": 3,
        "y": 6,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_1788945507082_245",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507080_180",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507080_944",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507081_823",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507082_580",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507081_385",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507080_17",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_1788945507081_967",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507080_102",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      }
    ]
  },
  {
    "id": "level_76",
    "number": 76,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_1788945507085_525",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_1788945507086_283",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_1788945507086_465",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_1788945507093_790",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945507085_298",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_28_1788945507089_419",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507086_385",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945507085_67",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_26_1788945507088_615",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_27_1788945507088_471",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507085_963",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507085_254",
        "x": 6,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507087_256",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945507085_751",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507087_660",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507087_925",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945507086_594",
        "x": 4,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507085_83",
        "x": 1,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945507085_944",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_13_1788945507086_104",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507086_438",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_1788945507085_918",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507086_977",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507087_523",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507085_614",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507087_268",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507087_235",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945507086_144",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507086_243",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507086_436",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      }
    ]
  },
  {
    "id": "level_77",
    "number": 77,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_1788945507096_160",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507097_215",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507097_337",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_4_1788945507095_275",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_1788945507103_373",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507097_822",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507095_942",
        "x": 0,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945507095_969",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_15_1788945507095_602",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_30_1788945507102_209",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507095_360",
        "x": 4,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507095_818",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_1788945507098_556",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945507095_485",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507095_820",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_2_1788945507095_287",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945507095_318",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507095_475",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_5_1788945507095_509",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507095_860",
        "x": 3,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507095_556",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507099_685",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507095_786",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945507095_994",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945507096_302",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507095_753",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945507095_582",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_20_1788945507096_242",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_1788945507095_112",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507095_70",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_23_1788945507097_860",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_78",
    "number": 78,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_22_1788945507106_986",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_1788945507107_896",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507103_263",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507103_290",
        "x": 7,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507105_5",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945507104_494",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507104_6",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507105_276",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507111_21",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507107_141",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507109_319",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507103_639",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507104_125",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507103_946",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507103_344",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945507103_578",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_4_1788945507103_948",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_12_1788945507103_451",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_1788945507103_888",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507103_172",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945507103_976",
        "x": 5,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507103_289",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_8_1788945507103_586",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_31_1788945507115_722",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945507108_537",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507103_88",
        "x": 6,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507103_933",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507103_845",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507110_415",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507104_92",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_79",
    "number": 79,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_14_1788945507116_841",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507119_786",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507118_91",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507115_62",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_13_1788945507116_954",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_0_1788945507115_541",
        "x": 5,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507119_651",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945507115_517",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_1788945507123_135",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507115_617",
        "x": 2,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_22_1788945507118_926",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_1788945507116_722",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_4_1788945507115_842",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945507115_111",
        "x": 4,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_19_1788945507116_122",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_20_1788945507117_386",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_30_1788945507123_109",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507115_2",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507115_228",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507115_369",
        "x": 4,
        "y": 6,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_31_1788945507124_553",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507116_211",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945507117_55",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945507116_788",
        "x": 2,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507116_169",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507116_887",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_1788945507118_724",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507116_259",
        "x": 3,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507115_705",
        "x": 4,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507116_920",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_80",
    "number": 80,
    "gridSize": 8,
    "difficulty": "Expert",
    "hearts": 3,
    "hints": 3,
    "coinReward": 20,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_25_1788945507128_668",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507124_100",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_22_1788945507126_520",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_1788945507124_275",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507124_884",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_17_1788945507124_518",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_9_1788945507124_253",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507124_661",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_19_1788945507125_897",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507124_279",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_1788945507124_741",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_24_1788945507128_587",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507124_8",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945507124_239",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507124_179",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507124_757",
        "x": 6,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_29_1788945507132_148",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507124_920",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_21_1788945507125_258",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507124_642",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_20_1788945507125_649",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507129_634",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507126_986",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507124_240",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507124_710",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_10_1788945507124_916",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945507124_995",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507129_381",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507124_775",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      }
    ]
  },
  {
    "id": "level_81",
    "number": 81,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_20_1788945507136_808",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507135_861",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507136_658",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945507136_299",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945507138_648",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507139_918",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_1788945507136_413",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507135_715",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_26_1788945507138_807",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945507135_351",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_29_1788945507141_43",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507135_234",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_28_1788945507140_258",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_33_1788945507145_864",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507136_430",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_35_1788945507149_562",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945507137_614",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_30_1788945507142_603",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_40_1788945507158_880",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507135_717",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_6_1788945507135_814",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507135_524",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945507137_301",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507136_55",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507135_903",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_18_1788945507136_450",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945507136_836",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507135_270",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507135_578",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507136_402",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_24_1788945507137_291",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507135_86",
        "x": 0,
        "y": 2,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507136_554",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507136_771",
        "x": 3,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_31_1788945507143_870",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_82",
    "number": 82,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_13_1788945507160_490",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_1788945507163_521",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507160_200",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507169_350",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_32_1788945507170_262",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945507160_260",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_23_1788945507163_866",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507160_672",
        "x": 5,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_7_1788945507160_579",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_0_1788945507160_143",
        "x": 4,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_1788945507168_460",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507160_937",
        "x": 4,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507161_616",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945507160_808",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_1788945507160_509",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945507160_753",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507161_382",
        "x": 5,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507160_846",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945507160_851",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507160_268",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507160_106",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_4_1788945507160_227",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_33_1788945507171_553",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507160_383",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_38_1788945507179_668",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_1788945507169_975",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507165_941",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_19_1788945507161_360",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507160_58",
        "x": 5,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_27_1788945507166_603",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945507162_479",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_28_1788945507166_105",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507160_54",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507165_515",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_83",
    "number": 83,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_4_1788945507185_975",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507187_570",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_34_1788945507199_639",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_2_1788945507185_18",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_26_1788945507192_243",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_11_1788945507185_700",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_1_1788945507185_43",
        "x": 4,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_20_1788945507187_744",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_30_1788945507195_976",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507188_744",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945507185_58",
        "x": 7,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945507185_136",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507185_350",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945507188_282",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507185_520",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945507185_382",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_24_1788945507189_143",
        "x": 5,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945507186_375",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507185_539",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507196_953",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507187_889",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_35_1788945507200_180",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_32_1788945507196_490",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507186_346",
        "x": 1,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_1788945507194_408",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507185_668",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507185_121",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_14_1788945507186_634",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507186_454",
        "x": 3,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507187_555",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_1788945507187_426",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_16_1788945507186_648",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_84",
    "number": 84,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_1788945507211_553",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507216_460",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507211_455",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507211_328",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507211_312",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507211_688",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_21_1788945507213_333",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_33_1788945507223_156",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_1788945507220_564",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507211_498",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507211_691",
        "x": 5,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_25_1788945507216_406",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945507215_410",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507212_873",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507212_205",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_11_1788945507211_426",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_24_1788945507215_558",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507211_174",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945507212_252",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_27_1788945507217_631",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945507211_8",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_10_1788945507211_897",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_18_1788945507212_33",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_6_1788945507211_434",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507211_410",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_15_1788945507211_418",
        "x": 3,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_30_1788945507220_108",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507212_269",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945507211_46",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_7_1788945507211_885",
        "x": 0,
        "y": 0,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_85",
    "number": 85,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_1788945507236_677",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_18_1788945507236_144",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_3_1788945507236_428",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_1788945507239_948",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945507236_781",
        "x": 4,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507236_402",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945507236_47",
        "x": 6,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507236_780",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_15_1788945507236_45",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945507236_490",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507236_858",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507236_593",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_33_1788945507242_746",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945507237_21",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507238_67",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_37_1788945507248_778",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507237_612",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_1788945507236_610",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507236_946",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_24_1788945507236_987",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_23_1788945507236_520",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_34_1788945507243_393",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507236_992",
        "x": 1,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507236_954",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507236_750",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_27_1788945507237_645",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507236_679",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507238_377",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507236_855",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507236_811",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945507236_752",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507236_689",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_21_1788945507236_818",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507236_801",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_1788945507239_724",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_86",
    "number": 86,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_8_1788945507254_861",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_16_1788945507255_985",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507256_481",
        "x": 7,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945507254_954",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_1788945507254_348",
        "x": 3,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_2_1788945507254_140",
        "x": 2,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_6_1788945507254_919",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_27_1788945507258_657",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_41_1788945507275_744",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507255_643",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_15_1788945507255_750",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_36_1788945507268_189",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507254_929",
        "x": 0,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507254_196",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_5_1788945507254_60",
        "x": 6,
        "y": 5,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_12_1788945507255_94",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507257_371",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507256_998",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507262_573",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507257_450",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945507254_907",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_9_1788945507254_22",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_29_1788945507260_301",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507257_104",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507255_627",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_32_1788945507263_176",
        "x": 6,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_1788945507266_197",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507256_848",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507257_97",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507255_394",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507254_973",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507255_780",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507254_278",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507255_593",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_87",
    "number": 87,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_18_1788945507278_545",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507275_786",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_3_1788945507275_701",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_11_1788945507276_51",
        "x": 4,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507277_181",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_1788945507276_323",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507276_57",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507279_328",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507275_359",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_12_1788945507276_350",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945507275_288",
        "x": 0,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507275_11",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_17_1788945507277_168",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507275_240",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945507275_220",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_13_1788945507276_264",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_1788945507276_337",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507285_346",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507275_668",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_22_1788945507282_52",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945507281_519",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507275_792",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_1788945507275_860",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      }
    ]
  },
  {
    "id": "level_88",
    "number": 88,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_26_1788945507311_804",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945507310_152",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945507310_141",
        "x": 1,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507309_534",
        "x": 6,
        "y": 7,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507309_1",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_25_1788945507311_284",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507309_114",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507310_431",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_30_1788945507314_856",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945507310_951",
        "x": 6,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507313_163",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945507310_631",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_32_1788945507314_97",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507309_853",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507310_892",
        "x": 7,
        "y": 4,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_16_1788945507310_474",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945507310_817",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507309_970",
        "x": 3,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507314_363",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_34_1788945507315_526",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507309_275",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_13_1788945507310_708",
        "x": 5,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507309_323",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_27_1788945507312_498",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_24_1788945507311_466",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_1_1788945507309_822",
        "x": 2,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507310_150",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507310_268",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507310_780",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_22_1788945507310_823",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507310_932",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_33_1788945507314_35",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507310_590",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507310_345",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507312_268",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_36_1788945507318_730",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_89",
    "number": 89,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945507326_736",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_20_1788945507327_833",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_26_1788945507331_586",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507326_685",
        "x": 4,
        "y": 6,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_30_1788945507335_499",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507326_192",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507326_570",
        "x": 5,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_9_1788945507326_241",
        "x": 1,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507328_564",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_38_1788945507345_322",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_1788945507335_577",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507334_20",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507327_199",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_1788945507326_774",
        "x": 7,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_3_1788945507326_86",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507326_292",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_8_1788945507326_988",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945507326_31",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_1_1788945507326_139",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_15_1788945507327_645",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_25_1788945507330_804",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507326_238",
        "x": 5,
        "y": 0,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_11_1788945507326_47",
        "x": 2,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945507327_669",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945507326_556",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_36_1788945507343_839",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507327_323",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507327_863",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_1788945507326_703",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_21_1788945507327_642",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507327_443",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_90",
    "number": 90,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_36_1788945507369_518",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507355_200",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945507351_913",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_10_1788945507351_689",
        "x": 7,
        "y": 3,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_4_1788945507351_799",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507351_45",
        "x": 5,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507351_847",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_18_1788945507352_991",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507351_766",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_14_1788945507351_902",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507356_176",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507351_349",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507351_634",
        "x": 6,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507351_573",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507351_414",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945507351_325",
        "x": 1,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945507354_901",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507351_246",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_19_1788945507352_608",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_29_1788945507359_329",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945507351_506",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_22_1788945507353_153",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945507352_969",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507352_197",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507351_601",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_15_1788945507351_283",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945507351_132",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507351_741",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_31_1788945507362_657",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_91",
    "number": 91,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_5_1788945507377_946",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507377_332",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507377_653",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_9_1788945507377_362",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_3_1788945507377_479",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507378_919",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507377_985",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945507377_681",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_8_1788945507377_775",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_16_1788945507378_645",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507378_253",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507377_528",
        "x": 2,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507379_784",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507377_936",
        "x": 3,
        "y": 5,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_22_1788945507378_625",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_28_1788945507380_497",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507378_51",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507380_246",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_37_1788945507392_890",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507379_582",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507377_483",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945507377_828",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_29_1788945507380_632",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_40_1788945507396_930",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507378_347",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_18_1788945507378_328",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507377_720",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945507378_916",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945507378_255",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945507377_709",
        "x": 4,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507380_586",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507377_233",
        "x": 1,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_92",
    "number": 92,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_19_1788945507399_610",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507397_888",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_4_1788945507397_436",
        "x": 3,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_21_1788945507400_844",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507398_101",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_17_1788945507398_973",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_28_1788945507405_820",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945507398_589",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_20_1788945507399_868",
        "x": 0,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945507397_666",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_14_1788945507398_176",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_32_1788945507410_44",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_0_1788945507397_998",
        "x": 2,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507397_938",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_23_1788945507401_97",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_5_1788945507397_420",
        "x": 6,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945507397_293",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_8_1788945507397_120",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 5
      },
      {
        "id": "arr_12_1788945507397_121",
        "x": 0,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_22_1788945507400_868",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507397_258",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507401_430",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_24_1788945507401_887",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945507398_125",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507397_816",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_16_1788945507398_859",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_6_1788945507397_187",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_9_1788945507397_981",
        "x": 0,
        "y": 1,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_93",
    "number": 93,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_16_1788945507425_304",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_17_1788945507425_144",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_3_1788945507425_808",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_14_1788945507425_776",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507425_620",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507428_451",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507425_957",
        "x": 3,
        "y": 7,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_27_1788945507431_865",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507425_815",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_26_1788945507430_668",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507425_705",
        "x": 5,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507425_236",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945507425_823",
        "x": 4,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_19_1788945507425_679",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_21_1788945507426_449",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_31_1788945507435_171",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507425_666",
        "x": 1,
        "y": 2,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_1788945507425_574",
        "x": 3,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_30_1788945507434_853",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507425_216",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507425_903",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_1788945507426_637",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507425_476",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_0_1788945507425_888",
        "x": 5,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507425_238",
        "x": 4,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_12_1788945507425_668",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945507426_12",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_18_1788945507425_596",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507426_197",
        "x": 1,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_94",
    "number": 94,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_0_1788945507450_132",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_3_1788945507450_374",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_2_1788945507450_996",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_22_1788945507453_4",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945507452_584",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_12_1788945507451_333",
        "x": 6,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_6_1788945507450_742",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_25_1788945507455_19",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507450_3",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_10_1788945507450_532",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507452_898",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_17_1788945507451_141",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_15_1788945507451_59",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_34_1788945507467_854",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_18_1788945507451_735",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_8_1788945507450_694",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_7_1788945507450_446",
        "x": 5,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507456_958",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_19_1788945507452_201",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507450_192",
        "x": 4,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_1788945507450_932",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945507454_443",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_28_1788945507458_635",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507451_949",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507451_729",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_4_1788945507450_166",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_14_1788945507451_297",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507453_603",
        "x": 1,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507451_884",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_95",
    "number": 95,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_17_1788945507478_949",
        "x": 5,
        "y": 2,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_14_1788945507478_946",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_1_1788945507477_245",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507478_763",
        "x": 3,
        "y": 2,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_20_1788945507479_552",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_24_1788945507480_342",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_1788945507477_9",
        "x": 2,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507481_437",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507478_53",
        "x": 2,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507479_630",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_10_1788945507478_384",
        "x": 6,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507478_953",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507485_646",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507477_118",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_16_1788945507478_41",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507478_638",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 5
      },
      {
        "id": "arr_2_1788945507477_11",
        "x": 6,
        "y": 4,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945507478_774",
        "x": 2,
        "y": 3,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_13_1788945507478_518",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_12_1788945507478_271",
        "x": 7,
        "y": 4,
        "direction": "UP",
        "length": 4
      },
      {
        "id": "arr_28_1788945507485_227",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507480_815",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507478_36",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_9_1788945507478_314",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945507480_431",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507478_796",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507480_671",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945507478_962",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 3
      }
    ]
  },
  {
    "id": "level_96",
    "number": 96,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_6_1788945507504_114",
        "x": 6,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_17_1788945507505_372",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_33_1788945507511_210",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_14_1788945507504_334",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_24_1788945507505_113",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507508_139",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_16_1788945507505_415",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_10_1788945507504_884",
        "x": 3,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_11_1788945507504_949",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507506_875",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_19_1788945507505_590",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_34_1788945507513_827",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_13_1788945507504_340",
        "x": 1,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_21_1788945507505_313",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507504_467",
        "x": 4,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945507504_616",
        "x": 7,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_8_1788945507504_205",
        "x": 3,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_23_1788945507505_637",
        "x": 5,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_31_1788945507510_324",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_2_1788945507504_638",
        "x": 0,
        "y": 6,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_3_1788945507504_622",
        "x": 2,
        "y": 3,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_26_1788945507506_258",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_4_1788945507504_637",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_1788945507507_624",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_32_1788945507510_451",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_7_1788945507504_452",
        "x": 4,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_5_1788945507504_179",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_1_1788945507504_658",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 5
      },
      {
        "id": "arr_18_1788945507505_42",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_25_1788945507506_454",
        "x": 6,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_22_1788945507505_339",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_9_1788945507504_646",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507505_298",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_15_1788945507504_704",
        "x": 0,
        "y": 2,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_97",
    "number": 97,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945507525_10",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_29_1788945507529_106",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507526_976",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_27_1788945507527_660",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507527_216",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507526_246",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_25_1788945507527_515",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_32_1788945507533_409",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507526_596",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_28_1788945507528_579",
        "x": 4,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_18_1788945507525_701",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_23_1788945507526_665",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507525_312",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_3_1788945507524_463",
        "x": 6,
        "y": 3,
        "direction": "DOWN",
        "length": 4
      },
      {
        "id": "arr_11_1788945507525_870",
        "x": 3,
        "y": 3,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_6_1788945507524_621",
        "x": 1,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_5_1788945507524_769",
        "x": 4,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_19_1788945507526_12",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945507526_209",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945507524_858",
        "x": 0,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507524_67",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_4_1788945507524_594",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_14_1788945507525_303",
        "x": 2,
        "y": 6,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_1_1788945507524_410",
        "x": 5,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507524_752",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_13_1788945507525_411",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_8_1788945507525_471",
        "x": 4,
        "y": 4,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_12_1788945507525_623",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_31_1788945507533_753",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507525_412",
        "x": 4,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507525_157",
        "x": 1,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507525_740",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      }
    ]
  },
  {
    "id": "level_98",
    "number": 98,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_23_1788945507549_388",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507547_886",
        "x": 7,
        "y": 5,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_29_1788945507553_704",
        "x": 7,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_11_1788945507547_457",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_15_1788945507548_420",
        "x": 4,
        "y": 7,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_28_1788945507552_679",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_17_1788945507548_30",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_8_1788945507547_136",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_6_1788945507547_367",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_27_1788945507551_857",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_2_1788945507547_800",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_7_1788945507547_801",
        "x": 6,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507547_359",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507551_392",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_14_1788945507547_289",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_20_1788945507548_364",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507548_488",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_5_1788945507547_165",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_24_1788945507550_441",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_21_1788945507549_827",
        "x": 0,
        "y": 6,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_10_1788945507547_698",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_3_1788945507547_653",
        "x": 2,
        "y": 0,
        "direction": "LEFT",
        "length": 3
      },
      {
        "id": "arr_22_1788945507549_357",
        "x": 7,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_0_1788945507547_909",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 3
      },
      {
        "id": "arr_18_1788945507548_489",
        "x": 6,
        "y": 0,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_19_1788945507548_632",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_1_1788945507547_397",
        "x": 6,
        "y": 3,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_25_1788945507551_754",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_12_1788945507547_372",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507547_753",
        "x": 4,
        "y": 2,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_38_1788945507565_328",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      }
    ]
  },
  {
    "id": "level_99",
    "number": 99,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_10_1788945507571_835",
        "x": 7,
        "y": 7,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_27_1788945507578_803",
        "x": 7,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507570_670",
        "x": 5,
        "y": 4,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_12_1788945507571_244",
        "x": 2,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_22_1788945507574_892",
        "x": 7,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_16_1788945507572_928",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507570_125",
        "x": 0,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507571_547",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_24_1788945507576_592",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507571_789",
        "x": 6,
        "y": 1,
        "direction": "RIGHT",
        "length": 2
      },
      {
        "id": "arr_29_1788945507581_902",
        "x": 0,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_20_1788945507573_393",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_2_1788945507570_273",
        "x": 3,
        "y": 3,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_0_1788945507570_894",
        "x": 7,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_18_1788945507573_707",
        "x": 6,
        "y": 4,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_15_1788945507571_272",
        "x": 0,
        "y": 1,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_1_1788945507570_283",
        "x": 7,
        "y": 6,
        "direction": "RIGHT",
        "length": 5
      },
      {
        "id": "arr_17_1788945507572_71",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 2
      },
      {
        "id": "arr_9_1788945507571_423",
        "x": 0,
        "y": 3,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507570_171",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_1788945507573_699",
        "x": 0,
        "y": 2,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_26_1788945507578_528",
        "x": 0,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_13_1788945507571_39",
        "x": 6,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_21_1788945507574_807",
        "x": 7,
        "y": 5,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507570_850",
        "x": 7,
        "y": 0,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_14_1788945507571_683",
        "x": 1,
        "y": 0,
        "direction": "LEFT",
        "length": 4
      },
      {
        "id": "arr_30_1788945507583_604",
        "x": 5,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_4_1788945507570_205",
        "x": 1,
        "y": 7,
        "direction": "LEFT",
        "length": 1
      }
    ]
  },
  {
    "id": "level_100",
    "number": 100,
    "gridSize": 8,
    "difficulty": "MASTER / EXTREME",
    "hearts": 3,
    "hints": 3,
    "coinReward": 30,
    "status": "Live",
    "arrows": [
      {
        "id": "arr_16_1788945507599_60",
        "x": 3,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_20_1788945507600_737",
        "x": 0,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_0_1788945507599_613",
        "x": 6,
        "y": 4,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_15_1788945507599_284",
        "x": 2,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_3_1788945507599_27",
        "x": 2,
        "y": 5,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_26_1788945507601_233",
        "x": 2,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_1_1788945507599_103",
        "x": 5,
        "y": 6,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_14_1788945507599_842",
        "x": 7,
        "y": 0,
        "direction": "RIGHT",
        "length": 4
      },
      {
        "id": "arr_21_1788945507600_405",
        "x": 2,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_25_1788945507601_471",
        "x": 0,
        "y": 4,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_11_1788945507599_11",
        "x": 6,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_8_1788945507599_854",
        "x": 0,
        "y": 1,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_17_1788945507599_216",
        "x": 2,
        "y": 3,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_13_1788945507599_909",
        "x": 7,
        "y": 1,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_24_1788945507601_139",
        "x": 1,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_33_1788945507609_730",
        "x": 3,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_34_1788945507610_897",
        "x": 7,
        "y": 2,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_7_1788945507599_379",
        "x": 7,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_18_1788945507600_832",
        "x": 1,
        "y": 1,
        "direction": "UP",
        "length": 2
      },
      {
        "id": "arr_19_1788945507600_831",
        "x": 0,
        "y": 7,
        "direction": "DOWN",
        "length": 2
      },
      {
        "id": "arr_12_1788945507599_39",
        "x": 1,
        "y": 6,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_10_1788945507599_775",
        "x": 4,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_2_1788945507599_29",
        "x": 4,
        "y": 1,
        "direction": "RIGHT",
        "length": 1
      },
      {
        "id": "arr_6_1788945507599_476",
        "x": 3,
        "y": 2,
        "direction": "UP",
        "length": 3
      },
      {
        "id": "arr_23_1788945507601_356",
        "x": 2,
        "y": 2,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_9_1788945507599_340",
        "x": 3,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_22_1788945507600_40",
        "x": 1,
        "y": 0,
        "direction": "UP",
        "length": 1
      },
      {
        "id": "arr_32_1788945507608_112",
        "x": 5,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_4_1788945507599_62",
        "x": 7,
        "y": 5,
        "direction": "DOWN",
        "length": 3
      },
      {
        "id": "arr_30_1788945507606_647",
        "x": 2,
        "y": 7,
        "direction": "DOWN",
        "length": 1
      },
      {
        "id": "arr_28_1788945507604_542",
        "x": 0,
        "y": 5,
        "direction": "LEFT",
        "length": 1
      },
      {
        "id": "arr_5_1788945507599_877",
        "x": 1,
        "y": 3,
        "direction": "DOWN",
        "length": 1
      }
    ]
  }
];
