import { Arrow } from '../types';

export function getArrowCells(arrow: Arrow): {x: number, y: number}[] {
  const cells = [];
  const len = arrow.length || 1;
  for (let i = 0; i < len; i++) {
    if (arrow.direction === 'UP') cells.push({ x: arrow.x, y: arrow.y + i });
    if (arrow.direction === 'DOWN') cells.push({ x: arrow.x, y: arrow.y - i });
    if (arrow.direction === 'LEFT') cells.push({ x: arrow.x + i, y: arrow.y });
    if (arrow.direction === 'RIGHT') cells.push({ x: arrow.x - i, y: arrow.y });
  }
  return cells;
}

export function isPathClear(arrow: Arrow, allArrows: Arrow[], gridSize: number): boolean {
  const occupied = new Set<string>();
  for (const other of allArrows) {
    if (other.id === arrow.id) continue;
    const cells = getArrowCells(other);
    for (const c of cells) {
      occupied.add(`${c.x},${c.y}`);
    }
  }

  let currX = arrow.x;
  let currY = arrow.y;
  while (true) {
    if (arrow.direction === 'UP') currY--;
    else if (arrow.direction === 'DOWN') currY++;
    else if (arrow.direction === 'LEFT') currX--;
    else if (arrow.direction === 'RIGHT') currX++;
    
    // Check if reached edge
    if (currX < 0 || currX >= gridSize || currY < 0 || currY >= gridSize) {
      break;
    }
    
    // Check if blocked
    if (occupied.has(`${currX},${currY}`)) {
      return false;
    }
  }
  return true;
}

export function getHint(allArrows: Arrow[], gridSize: number): Arrow | null {
  for (const arrow of allArrows) {
    if (isPathClear(arrow, allArrows, gridSize)) {
      return arrow;
    }
  }
  return null;
}

export function checkSolvability(arrows: Arrow[], gridSize: number): boolean {
  if (arrows.length === 0) return true;
  let currentArrows = [...arrows];

  // Try to solve by iteratively removing free arrows
  while (currentArrows.length > 0) {
    let removedAny = false;
    
    for (let i = 0; i < currentArrows.length; i++) {
      if (isPathClear(currentArrows[i], currentArrows, gridSize)) {
        currentArrows.splice(i, 1);
        removedAny = true;
        break; // Start over with the new state
      }
    }
    
    if (!removedAny) {
      // We couldn't remove any arrows, but there are still arrows left
      // This means the puzzle is unsolvable
      return false;
    }
  }
  return true;
}

export function getBlockingArrowIds(arrow: Arrow, allArrows: Arrow[], gridSize: number): string[] {
  const occupiedBy = new Map<string, string>();
  for (const other of allArrows) {
    if (other.id === arrow.id) continue;
    const cells = getArrowCells(other);
    for (const c of cells) {
      occupiedBy.set(`${c.x},${c.y}`, other.id);
    }
  }

  let currX = arrow.x;
  let currY = arrow.y;
  while (true) {
    if (arrow.direction === 'UP') currY--;
    else if (arrow.direction === 'DOWN') currY++;
    else if (arrow.direction === 'LEFT') currX--;
    else if (arrow.direction === 'RIGHT') currX++;
    
    if (currX < 0 || currX >= gridSize || currY < 0 || currY >= gridSize) {
      break;
    }
    
    const cellKey = `${currX},${currY}`;
    if (occupiedBy.has(cellKey)) {
      return [arrow.id, occupiedBy.get(cellKey)!];
    }
  }
  return [];
}
