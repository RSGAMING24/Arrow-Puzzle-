export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export interface Arrow {
  id: string;
  x: number;
  y: number;
  direction: Direction;
  length: number;
}

export interface LevelData {
  id: string;
  number: number;
  gridSize: number;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Expert' | 'Very Easy' | 'Medium/Hard' | 'Very Hard' | 'MASTER / EXTREME';
  hearts: number;
  hints: number;
  coinReward: number;
  arrows: Arrow[];
  status: 'Draft' | 'Live';
}

export interface PlayerProgress {
  currentLevel: number;
  unlockedLevels: number[];
  completedLevels: Record<number, { stars: number; moves: number; mistakes: number }>;
  coins: number;
  dailyRewards?: {
    lastClaimDate: string | null;
    currentDay: number;
  };
  settings: {
    sound: boolean;
    vibration: boolean;
    theme: 'Light' | 'Dark' | 'System';
  };
  inventory?: {
    ownedColors: string[];
    ownedThemes: string[];
    ownedAnimations: string[];
    globalHints: number;
    globalHearts: number;
  };
  equipped?: {
    color: string | null;
    theme: string | null;
    animation: string | null;
  };
  spinState?: {
    count: number;
    lastDate: string;
  };
  lastMysteryGiftTime?: number;
  adTracking?: {
    lastSpinAdDate: string | null;
    dailySpinAdsWatched: number;
  };
}
