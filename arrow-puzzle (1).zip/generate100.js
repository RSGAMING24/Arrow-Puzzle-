import fs from 'fs';

function getArrowCells(arrow) {
  const cells = [];
  const len = arrow.length || 1;
  for (let i = 0; i < len; i++) {
    if (arrow.direction === 'UP') cells.push({ x: arrow.x, y: arrow.y + i });
    if (arrow.direction === 'DOWN') cells.push({ x: arrow.x, y: arrow.y - i });
    if (arrow.direction === 'LEFT') cells.push({ x: arrow.x + i, y: arrow.y });
    if (arrow.direction === 'RIGHT') cells.push({ x: arrow.x - i, y: arrow.y });
  }
  return cells;
}

function overlaps(arrow, existingArrows, gridSize) {
  const cells = getArrowCells(arrow);
  for (const c of cells) {
    if (c.x < 0 || c.x >= gridSize || c.y < 0 || c.y >= gridSize) return true; // out of bounds
  }
  const occupied = new Set();
  for (const other of existingArrows) {
    const oCells = getArrowCells(other);
    for (const c of oCells) {
      occupied.add(`${c.x},${c.y}`);
    }
  }
  for (const c of cells) {
    if (occupied.has(`${c.x},${c.y}`)) return true;
  }
  return false;
}

function isPathClear(arrow, existingArrows, gridSize) {
  const occupied = new Set();
  for (const other of existingArrows) {
    const cells = getArrowCells(other);
    for (const c of cells) {
      occupied.add(`${c.x},${c.y}`);
    }
  }
  let currX = arrow.x;
  let currY = arrow.y;
  while (true) {
    if (arrow.direction === 'UP') currY--;
    else if (arrow.direction === 'DOWN') currY++;
    else if (arrow.direction === 'LEFT') currX--;
    else if (arrow.direction === 'RIGHT') currX++;
    
    // Check if reached edge
    if (currX < 0 || currX >= gridSize || currY < 0 || currY >= gridSize) {
      break;
    }
    
    // Check if blocked
    if (occupied.has(`${currX},${currY}`)) {
      return false;
    }
  }
  return true;
}

function generateLevel(levelNum) {
  let gridSize = 4;
  let numArrows = 4;
  let maxArrowLength = 1;
  let difficulty = 'Easy';
  
  if (levelNum <= 5) {
    gridSize = Math.floor(Math.random() * 2) + 4; // 4-5
    numArrows = Math.floor(gridSize * 1.5);
    maxArrowLength = 2;
    difficulty = 'Very Easy';
  } else if (levelNum <= 15) {
    gridSize = Math.floor(Math.random() * 2) + 5; // 5-6
    numArrows = Math.floor(gridSize * 2);
    maxArrowLength = 3;
    difficulty = 'Easy';
  } else if (levelNum <= 25) {
    gridSize = Math.floor(Math.random() * 2) + 5; // 5-6
    numArrows = Math.floor(gridSize * 2.5);
    maxArrowLength = 3;
    difficulty = 'Medium';
  } else if (levelNum <= 40) {
    gridSize = Math.floor(Math.random() * 2) + 6; // 6-7
    numArrows = Math.floor(gridSize * 3);
    maxArrowLength = 4;
    difficulty = 'Hard';
  } else if (levelNum <= 60) {
    gridSize = Math.floor(Math.random() * 2) + 7; // 7-8
    numArrows = Math.floor(gridSize * 3.5);
    maxArrowLength = 4;
    difficulty = 'Very Hard';
  } else if (levelNum <= 80) {
    gridSize = 8;
    numArrows = 32;
    maxArrowLength = 5;
    difficulty = 'Expert';
  } else {
    gridSize = 8;
    numArrows = 42;
    maxArrowLength = 5;
    difficulty = 'MASTER / EXTREME';
  }

  let coinReward = 5;
  if (levelNum <= 5) coinReward = 3;
  else if (levelNum <= 15) coinReward = 5;
  else if (levelNum <= 25) coinReward = 8;
  else if (levelNum <= 40) coinReward = 10;
  else if (levelNum <= 60) coinReward = 15;
  else if (levelNum <= 80) coinReward = 20;
  else coinReward = 30;

  const arrows = [];
  for (let i = 0; i < numArrows; i++) {
    let placed = false;
    for (let attempts = 0; attempts < 200; attempts++) {
      const x = Math.floor(Math.random() * gridSize);
      const y = Math.floor(Math.random() * gridSize);
      const dirs = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
      const direction = dirs[Math.floor(Math.random() * dirs.length)];
      // Random length biased towards 1 or 2, but can be up to maxArrowLength
      const length = Math.floor(Math.pow(Math.random(), 1.5) * maxArrowLength) + 1;
      
      const newArrow = { id: `arr_${i}_${Date.now()}_${Math.floor(Math.random()*1000)}`, x, y, direction, length };
      
      if (overlaps(newArrow, arrows, gridSize)) continue;
      
      if (isPathClear(newArrow, arrows, gridSize)) {
        arrows.push(newArrow);
        placed = true;
        break;
      }
    }
  }

  // Scramble arrows array so they aren't visually ordered by the solver
  for (let i = arrows.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arrows[i], arrows[j]] = [arrows[j], arrows[i]];
  }

  return {
    id: `level_${levelNum}`,
    number: levelNum,
    gridSize,
    difficulty,
    hearts: 3,
    hints: 3,
    coinReward,
    status: 'Live',
    arrows
  };
}

const levels = [];
for (let i = 1; i <= 100; i++) {
  levels.push(generateLevel(i));
}

const fileContent = `import { LevelData } from '../types';\n\nexport const defaultLevels: LevelData[] = ${JSON.stringify(levels, null, 2)};\n`;
fs.writeFileSync('src/lib/defaultLevels.ts', fileContent);
console.log('100 Levels generated successfully!');
