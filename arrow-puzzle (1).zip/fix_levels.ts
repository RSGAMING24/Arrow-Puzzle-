import { defaultLevels } from './src/lib/defaultLevels';
import * as fs from 'fs';

let outOfBoundsCount = 0;
let totalArrows = 0;
let modifications = 0;

for (const level of defaultLevels) {
  for (const arrow of level.arrows) {
    totalArrows++;
    let len = arrow.length || 1;
    let oldLen = len;
    
    // clamp logic
    if (arrow.direction === 'UP') {
      len = Math.min(len, level.gridSize - arrow.y);
    } else if (arrow.direction === 'DOWN') {
      len = Math.min(len, arrow.y + 1);
    } else if (arrow.direction === 'LEFT') {
      len = Math.min(len, level.gridSize - arrow.x);
    } else if (arrow.direction === 'RIGHT') {
      len = Math.min(len, arrow.x + 1);
    }
    
    if (len < 1) len = 1; // should not happen if x,y are in bounds
    
    if (len !== oldLen) {
      arrow.length = len;
      modifications++;
    }
  }
}

console.log(`Modifications: ${modifications} / ${totalArrows}`);

// write back
const jsonStr = JSON.stringify(defaultLevels, null, 2);
const newFileContent = `import { LevelData } from '../types';\n\nexport const defaultLevels: LevelData[] = ${jsonStr};\n`;
fs.writeFileSync('src/lib/defaultLevels.ts', newFileContent);
console.log('Saved src/lib/defaultLevels.ts');
