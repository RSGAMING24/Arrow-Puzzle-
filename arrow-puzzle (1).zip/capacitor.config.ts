import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.arrowpuzzle',
  appName: 'Arrow Puzzle',
  webDir: 'dist'
};

export default config;
